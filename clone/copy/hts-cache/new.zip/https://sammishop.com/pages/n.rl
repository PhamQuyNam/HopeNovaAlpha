<!DOCTYPE html>
<html lang="vi">
	<head>
		<meta charset="utf-8" />
		<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' /><![endif]-->
		<!--[if lt IE 9]><script src="//hsta tic.net/0/0/global/design/theme-default/html5shiv.js"></script><![endif]-->
		<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
		<meta name="revisit-after" content="1 day" />
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="HandheldFriendly" content="true">
		<link rel="shortcut icon" href="//theme.hstatic.net/200000551679/1001345525/14/favicon.png?v=1469" type="image/png" />
		<title>
			Kh&#244;ng t&#236;m thấy trang &ndash; SammiShop
		</title>

		<script type="text/javascript">var _0x531f=["\x75\x73\x65\x72\x41\x67\x65\x6E\x74\x44\x61\x74\x61","\x75\x6E\x64\x65\x66\x69\x6E\x65\x64","\x62\x72\x61\x6E\x64\x73","\x62\x72\x61\x6E\x64","\x4C\x69\x67\x68\x74\x68\x6F\x75\x73\x65","\x66\x69\x6E\x64"];var _0x2366=[_0x531f[0],_0x531f[1],_0x531f[2],_0x531f[3],_0x531f[4],_0x531f[5]];var _0x94e8=[_0x2366[0],_0x2366[1],_0x2366[2],_0x2366[3],_0x2366[4],_0x2366[5]];var _0x8f7d=[_0x94e8[0],_0x94e8[1],_0x94e8[2],_0x94e8[3],_0x94e8[4],_0x94e8[5]];var f1genzPS=!Boolean( typeof (navigator[_0x8f7d[0]])!== _0x8f7d[1]&&  typeof (navigator[_0x8f7d[0]][_0x8f7d[2]])!== _0x8f7d[1]&& navigator[_0x8f7d[0]][_0x8f7d[2]][_0x8f7d[5]]((_0x7373x5)=>{return _0x7373x5[_0x8f7d[3]]=== _0x8f7d[4]}))</script>
		<script>
			if (f1genzPS) {
				!(function (e, s, t) {
					var n = s.getElementsByTagName(t)[0],
							a = s.createElement(t);
					(a.async = !0),
						(a.src = "https://assets.harafunnel.com/widget/442632045777507/1463076.js"),
						n.parentNode.insertBefore(a, n);
				})(window, document, "script");
			}
		</script>


		<style>
			.wauto{
				height:auto !important;
			}
			#articleBody img{ width: auto; }
			#articleBody img:not([src]){ display: none }; 
		</style>
		<link rel="canonical" href="" />
		<link rel="alternate" href="" hreflang="vi-vn" />	
		<meta name="keywords" content="SammiShop">
		<meta name="robots" content="index,follow,noodp"> 
		

<style>
	#articleBody img{ width: auto; }
  #articleBody img:not([src]){ display: none }; 
	.wauto{
		height:auto;
		width:auto;
	}
</style>

<link rel="dns-prefetch" href="https://sammishop.com">
<link rel="dns-prefetch" href="//hstatic.net">
<link rel="dns-prefetch" href="//theme.hstatic.net/">
<link rel="dns-prefetch" href="//file.hstatic.net/">
<link rel="dns-prefetch" href="//stats.hstatic.net/">
<link rel="dns-prefetch" href="//www.google-analytics.com/">
<link rel="dns-prefetch" href="//www.googletagmanager.com/">
<link rel="dns-prefetch" href="//www.google.com">
<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="dns-prefetch" href="//www.facebook.com">
<link rel="dns-prefetch" href="//connect.facebook.net">
<link rel="dns-prefetch" href="//static.ak.facebook.com">
<link rel="dns-prefetch" href="//static.ak.fbcdn.net">
<link rel="dns-prefetch" href="//s-static.ak.facebook.com">
<link rel="preconnect" href="https://product.hstatic.net" />
<link rel="preconnect" href="https://theme.hstatic.net" />
<link rel="preconnect" href="https://file.hstatic.net" />

<link rel="preload" as='style' type="text/css" href="//theme.hstatic.net/200000551679/1001345525/14/main.scss.css?v=1469">
<link rel="preload" as='style'  type="text/css" href="//theme.hstatic.net/200000551679/1001345525/14/index.scss.css?v=1469">
<link rel="preload" as='style'  type="text/css" href="//theme.hstatic.net/200000551679/1001345525/14/bootstrap-4-3-min.css?v=1469">

<link rel="preload" as='style'  type="text/css" href="//theme.hstatic.net/200000551679/1001345525/14/responsive.scss.css?v=1469">
<link rel="preload" as='style'  type="text/css" href="//theme.hstatic.net/200000551679/1001345525/14/product_infor_style.scss.css?v=1469">
<link rel="preload" as='style'  type="text/css" href="//theme.hstatic.net/200000551679/1001345525/14/quickviews_popup_cart.scss.css?v=1469">









<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/slider_1_master.jpg?v=1469">












<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_1_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_2_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_3_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_4_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_5_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_6_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_7_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_8_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_9_medium.jpg?v=1469">










<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coll_10_medium.jpg?v=1469">






<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coupon_1_img_medium.png?v=1469">

<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coupon_2_img_medium.png?v=1469">

<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coupon_3_img_medium.png?v=1469">

<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coupon_4_img_medium.png?v=1469">

<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coupon_5_img_medium.png?v=1469">

<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coupon_6_img_medium.png?v=1469">

<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coupon_7_img_medium.png?v=1469">

<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/coupon_8_img_medium.png?v=1469">




<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/top_banner.jpg?v=1469"  media="screen and (min-width: 480px)">
<link rel="preload" as="image" href="//theme.hstatic.net/200000551679/1001345525/14/top_banner_mb.jpg?v=1469"  media="screen and (max-width: 480px)">










































		

	<meta property="og:type" content="website">
	<meta property="og:title" content="Không tìm thấy trang">
	<meta property="og:image" content="https://theme.hstatic.net/200000551679/1001345525/14/share_fb_home.jpg?v=1469">
	<meta property="og:image:secure_url" content="https://theme.hstatic.net/200000551679/1001345525/14/share_fb_home.jpg?v=1469">


<meta property="og:description" content="">
<meta property="og:url" content="">
<meta property="og:site_name" content="SammiShop">
		<link rel="icon" href="//theme.hstatic.net/200000551679/1001345525/14/favicon.png?v=1469" type="image/x-icon" />


		
		<link rel="stylesheet" rel="preload stylesheet" as="style" fetchpriority="low" href="//theme.hstatic.net/200000551679/1001345525/14/bootstrap-4-3-min.css?v=1469">
				<style>
			:root{
				--text-color: #000000;
				--text-secondary-color:#666666;
				--primary-color: #d82e4d;
				--secondary-color:#d82e4d;
				--price-color: #f3283d;
				--topbar-bg: #fdd835;
				--topbar-color: #000000;
				--subheader-background: #e5677d;
				--subheader-color: #ffffff;
				--label-background: #fed632;
				--label-color: #ee4d2d;
				--footer-bg:#efefef;
				--footer-color:#000000;
				--show-loadmore: none!important;				--order-loadmore: -1!important;				--sale-pop-color: #d82e4d;
				--buynow-color: #d82e4d;
				--addtocart-color: #d82e4d;
				--cta-color: #d82e4d;
				--coupon-title-color: #d82e4d;
				--coupon-button-color: #d82e4d;
				--col-menu: 3;
			}
			.modal-scrollbar-measure {
				display: none;
			}
		</style> 
		<link href='//theme.hstatic.net/200000551679/1001345525/14/main.scss.css?v=1469' rel='stylesheet' type='text/css'  media='all'  />	
<link href='//theme.hstatic.net/200000551679/1001345525/14/cusnew.scss.css?v=1469' rel='stylesheet' type='text/css'  media='all'  />
		<link href='//theme.hstatic.net/200000551679/1001345525/14/product_infor_style.scss.css?v=1469' rel='stylesheet' type='text/css'  media='all'  />
		<link href='//theme.hstatic.net/200000551679/1001345525/14/quickviews_popup_cart.scss.css?v=1469' rel='stylesheet' type='text/css'  media='all'  />
		
		
		
		
		
		
		
		
		
		<link rel="preload" as="script" href="//theme.hstatic.net/200000551679/1001345525/14/jquery.js?v=1469" />
		<script src='//theme.hstatic.net/200000551679/1001345525/14/jquery.js?v=1469' type='text/javascript'></script>
		
		<link rel="preload" as="script" href="//theme.hstatic.net/200000551679/1001345525/14/slick-min.js?v=1469" />
		<script src='//theme.hstatic.net/200000551679/1001345525/14/slick-min.js?v=1469' type='text/javascript'></script>
		
		<link href='//theme.hstatic.net/200000551679/1001345525/14/responsive.scss.css?v=1469' rel='stylesheet' type='text/css'  media='all'  />		
		<link href='//theme.hstatic.net/200000551679/1001345525/14/abc.scss.css?v=1469' rel='stylesheet' type='text/css'  media='all'  />	







				
				<script type='text/javascript'>
if(f1genzPS){
if ((typeof Haravan) === 'undefined') {
  Haravan = {};
}
Haravan.culture = 'vi-VN';
Haravan.shop = 'sammishop-2.myharavan.com';
Haravan.theme = {"name":"CUS SEARCH","id":1001345525,"role":"main"};
Haravan.domain = 'sammishop.com';
}
</script>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11043869915"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11043869915');
</script>
<meta name="google-site-verification" content="X_0Viyjbn4HG3IM204Llv7Bk0j61kTvYclK7DDHvAJ8" /><script>
if(f1genzPS){
(function() { function asyncLoad() { var urls = ["https://app.hstatic.net/socialloginplus/200000551679/script-tag.js?v=1687508979691","https://buyxgety-omni.haravan.com/js/script_tag_production.js?v=1576487994026"];for (var i = 0; i < urls.length; i++) {var s = document.createElement('script');s.type = 'text/javascript';s.async = true;s.src = urls[i];var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);}}window.attachEvent ? window.attachEvent('onload', asyncLoad) : window.addEventListener('load', asyncLoad, false);})();
}
</script>
<script defer src='https://stats.hstatic.net/beacon.min.js' hrv-beacon-t='200000551679'></script><style>.grecaptcha-badge{visibility:hidden;}</style>
<script type='text/javascript'>
window.HaravanAnalytics = window.HaravanAnalytics || {};
window.HaravanAnalytics.meta = window.HaravanAnalytics.meta || {};
window.HaravanAnalytics.meta.currency = 'VND';
var meta = {"page":{"pageType":"page"}};
for (var attr in meta) {
	window.HaravanAnalytics.meta[attr] = meta[attr];
}
window.HaravanAnalytics.AutoTrack = true;
</script>
<script>
window.HaravanAnalytics.fb = "565175335531567";
if(f1genzPS){
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','//connect.facebook.net/en_US/fbevents.js');
// Insert Your Facebook Pixel ID below. 
fbq('init', "565175335531567", {} , {'agent':'plharavan'});
fbq('track', 'PageView');
}
</script>
<noscript><img height='1' width='1' style='display:none' src='https://www.facebook.com/tr?id=565175335531567&amp;ev=PageView&amp;noscript=1'/></noscript><!-- Event snippet for PAGE_VIEW-200000551679-12/13/2022 04:15:39 conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-11043869915/VzRuCOi6_YQYENupkJIp'});
</script>

		
		


		<script>
			var check_cc_dg = 299000;
		</script>



		
		
		
<script defer fetchpriority="low" src="//theme.hstatic.net/200000551679/1001345525/14/ega-app-buyxgety.js?v=1469"></script>






	


<div id="quick-view-product" class="quickview-product" style="display:none;">
	<div class="quickview-overlay fancybox-overlay fancybox-overlay-fixed"></div>
	<div class="quick-view-product align-verticle"></div>
	<div id="quickview-modal" style="display:none;">
		<div class="block-quickview primary_block details-product">
			<div class="row">
				<div class="product-left-column product-images col-xs-12 col-sm-4 col-md-4 col-lg-5 col-xl-6">
					<div class="image-block large-image col_large_default">
						<span class="view_full_size">
							<a class="img-product d-block  pos-relative embed-responsive embed-responsive-1by1" title="" href="javascript:;">
								<img src="//theme.hstatic.net/200000551679/1001345525/14/noimage.gif?v=1469" id="product-featured-image-quickview" class="img-responsive product-featured-image-quickview" alt="quickview"  />
							</a>
						</span>
						<div class="loading-imgquickview" style="display:none;"></div>
					</div>
					<div class="more-view-wrapper clearfix">
						<div class="thumbs_quickview owl_nav_custome1" id="thumbs_list_quickview">
							<ul class="product-photo-thumbs quickview-more-views-owlslider not-thuongdq" id="thumblist_quickview"></ul>
						</div>
					</div>
				</div>
				<div class="product-center-column product-info product-item col-xs-12 col-sm-6 col-md-8 col-lg-7 col-xl-6 details-pro style_product style_border">

					<div class="head-qv group-status">
						<h3 class="qwp-name title-product">abc</h3>
						<div class="vend-qv group-status">
							<div class="left_vend">
								<div class="first_status  d-inline-block">Thương hiệu:
									<span class="vendor_ status_name"></span>
								</div>		
								<span class="line_tt ">|</span>
								<div class="top_sku first_status d-inline-block">Mã sản phẩm:
									<span class="sku_ status_name"></span>
								</div>
							</div>
						</div>
					</div>
					<div class="quickview-info">
						<span class="prices price-box">
							<span class="price product-price"></span>
							<del class="old-price"></del>
							<span class="label_product"></span>
						</span>
						
																		<div class="buyxgety-box hidden quickview">
	<h3 class="buyxgety-header">Các sản phẩm được khuyến mãi</h3>
	<div class="buyxgety-product-list" data-id="" data-title="">
		<div class="buyxgety_content">
			<div class="buyxgety_lists">
			</div>
		</div>
	</div>
</div>


						
					</div>
					

					
					<form action="/cart/add" method="post" enctype="multipart/form-data" class="quick_option variants form-ajaxtocart form-product">
						<span class="price-product-detail hidden" style="opacity: 0;">
							<span class=""></span>
						</span>
						<select name='variantId' class="hidden" style="display:none"></select>
						<div class="form-group form_product_content">
							<div class="count_btn_style quantity_wanted_p">
								<div class="custom input_number_product soluong1">									
									<button class="btn_num btn num_1 button button_qty" onClick="var result = document.getElementById('quantity-detail'); var qtyqv = result.value; if( !isNaN( qtyqv ) &amp;&amp; qtyqv &gt; 1 ) result.value--;return false;">
										<svg class="icon">
	<use xlink:href="#icon-minus" />
</svg></button>
									<input type="text" id="quantity-detail" name="quantity" value="1" maxlength="2" class="form-control prd_quantity" onkeypress="if ( isNaN(this.value + String.fromCharCode(event.keyCode) )) return false;" onchange="if(this.value == 0)this.value=1;">
									<button class="btn_num  btn num_2 button button_qty" onClick="var result = document.getElementById('quantity-detail'); var qtyqv = result.value; if( !isNaN( qtyqv )) result.value++;return false;">
										<svg class="icon">
	<use xlink:href="#icon-plus" />
</svg>									</button>
								</div>
								<div class="button_actions clearfix">
									<button type="submit" class="btn_cool btn btn_base fix_add_to_cart ajax_addtocart btn_add_cart btn-cart add_to_cart_detail">
										<span class="btn-content text_1">Thêm vào giỏ hàng</span>
									</button>
								</div>
							</div>
						</div>

					</form>

				</div>
			</div>
		</div>      
		<a title="Close" class="quickview-close close-window" href="javascript:;"><i class="fas fa-times"></i></a>
	</div>    
</div>
<script type="text/javascript"> 
	Haravan.doNotTriggerClickOnThumb = false;
	function changeImageQuickView(img, selector) {
		var src = $(img).attr("src");
		src = src.replace("_compact", "");
		
		var $videoEl = $(selector).parent();
		
		if($(img).hasClass('video')){
			$(selector).parent().find('img').hide()
			var codevideo = $(img).parent().data().videocode.split("_")[1];
			var videoHtml = `<iframe class="img-responsive " width="560" height="315" src="https://www.youtube.com/embed/${codevideo}?autoplay=1&mute=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`;
			$videoEl.append(videoHtml);
		}else{
			$videoEl.find("iframe").remove();
			$(selector).parent().find('img').show()

			$(selector).attr("src", src);
		}
	}
	function validate(evt) {
		var theEvent = evt || window.event;
		var key = theEvent.keyCode || theEvent.which;
		key = String.fromCharCode( key );
		var regex = /[0-9]|\./;
		if( !regex.test(key) ) {
			theEvent.returnValue = false;
			if(theEvent.preventDefault) theEvent.preventDefault();
		}
	}
	var selectCallbackQuickView = function(variant, selector) {
		$('#quick-view-product form').show();
		var productItem = jQuery('.quick-view-product .product-item'),
			addToCart = productItem.find('.add_to_cart_detail'),
			productPrice = productItem.find('.price'),
			comparePrice = productItem.find('.old-price'),
			discountLabel= productItem.find('.label_product'),
			form2 = jQuery('.soluong1'),
			status = productItem.find('.soluong'),
			sku = productItem.find('.sku_'),
			totalPrice = productItem.find('.total-price span');

		if(variant && variant.sku ){
			sku.text(variant.sku);
		}else{
			sku.text('Đang cập nhật');
		}
		if (variant && variant.available) {

			var form = jQuery('#' + selector.domIdPrefix).closest('form');
			for (var i=0,length=variant.options.length; i<length; i++) {
				var radioButton = form.find('.swatch[data-option-index="' + i + '"] :radio[value="' + variant.options[i] +'"]');
				if (radioButton.size()) {
					radioButton.get(0).checked = true;
				}
			}

			addToCart.removeClass('disabled').removeAttr('disabled');
			addToCart.html('<span class="btn-image"></span><span class="btn-content text_1">Thêm vào giỏ hàng</span>').removeAttr('disabled');
			status.text('Còn hàng');
			if(variant.price < 1){			   
				$("#quick-view-product .price").html('Liên hệ');
				$("#quick-view-product del, #quick-view-product .quantity_wanted_p").hide();
				$("#quick-view-product .prices .old-price").hide();
				
								discountLabel.hide()

				form2.hide();
			}else{
				productPrice.html(Haravan.formatMoney(variant.price, "{{amount}}₫"));
													 if ( variant.compare_at_price > variant.price ) {
								  comparePrice.html(Haravan.formatMoney(variant.compare_at_price, "{{amount}}₫")).show();         
				  let save = variant.compare_at_price - variant.price;
				  let savePerCent = Math.ceil(save / variant.compare_at_price * 100);
				  if(savePerCent > 99){
				  	savePerCent = 99
				  }
				  if(savePerCent < 1){
				  	savePerCent = 1
				  }
				  discountLabel.html('-'+savePerCent+ "%").show()
				productPrice.addClass('on-sale');
			} else {
				comparePrice.hide();
				discountLabel.hide()
				productPrice.removeClass('on-sale');
			}

			$(".quantity_wanted_p").show();
			$(".input_qty_qv_").show();
			form2.show();
		}


		
		updatePricingQuickView();
		
							/*begin variant image*/
							if (variant && variant.featured_image) {

			var originalImage = $("#product-featured-image-quickview");
			var newImage = variant.featured_image;
			var element = originalImage[0];
			Haravan.Image.switchImage(newImage, element, function (newImageSizedSrc, newImage, element) {
				$('#thumblist_quickview img').each(function() {
					var parentThumbImg = $(this).parent();
					var productImage = $(this).parent().data("image");
					if (newImageSizedSrc.includes(productImage)) {
						$(this).parent().trigger('click');
						return false;
					}
				});

			});
			$('#product-featured-image-quickview').attr('src',variant.featured_image.src);
		}
	} else {
		addToCart.addClass('disabled').attr('disabled', 'disabled');
		addToCart.removeClass('hidden').addClass('btn_buy').attr('disabled','disabled').html('<div class="disabled">Hết hàng</div>').show();
		status.text('Hết hàng');
		$(".quantity_wanted_p").show();
		if(variant){
			if(variant.price < 1){			   
				$("#quick-view-product .price").html('Liên hệ');
				$("#quick-view-product del").hide();
				//$("#quick-view-product .quantity_wanted_p").hide();
				$("#quick-view-product .prices .old-price").hide();
								discountLabel.hide()

				form2.hide();
				comparePrice.hide();
				discountLabel.hide();
				productPrice.removeClass('on-sale');
				addToCart.addClass('disabled').attr('disabled', 'disabled');
				addToCart.removeClass('hidden').addClass('btn_buy').attr('disabled','disabled').html('<div class="disabled">Hết hàng</div>').show();			   
			}else{
				productPrice.html(Haravan.formatMoney(variant.price, "{{amount}}₫"));
				if ( variant.compare_at_price > variant.price ) {
					comparePrice.html(Haravan.formatMoney(variant.compare_at_price, "{{amount}}₫")).show();         
														 productPrice.addClass('on-sale');
					let save = variant.compare_at_price - variant.price;
                    let savePerCent = Math.ceil(save / variant.compare_at_price * 100);
					if(savePerCent > 99){
						savePerCent = 99
					}
					if(savePerCent < 1){
						savePerCent = 1
					}
					discountLabel.html('-'+savePerCent+ "%").show()
				} else {
					comparePrice.hide();
					discountLabel.hide();

					productPrice.removeClass('on-sale');
					$("#quick-view-product .prices .old-price").html('');
									discountLabel.hide()

				}
				$("#quick-view-product .price").html(Haravan.formatMoney(variant.price, "{{amount}}₫"));
																		$("#quick-view-product del ").hide();
													 $("#quick-view-product .prices .old-price").show();
								discountLabel.show()

				$(".input_qty_qv_").hide();
				form2.hide();
				addToCart.addClass('disabled').attr('disabled', 'disabled');
				addToCart.removeClass('hidden').addClass('btn_buy').attr('disabled','disabled').html('<div class="disabled">Hết hàng</div>').show();
			}
		}else{
			$("#quick-view-product .price").html('Liên hệ');
			$("#quick-view-product del").hide();
			$("#quick-view-product .quantity_wanted_p").hide();
			$("#quick-view-product .prices .old-price").hide();
							discountLabel.hide()

			form2.hide();
			comparePrice.hide();
			discountLabel.hide();

			productPrice.removeClass('on-sale');
			addToCart.addClass('disabled').attr('disabled', 'disabled');
			addToCart.removeClass('hidden').addClass('btn_buy').attr('disabled','disabled').html('<div class="disabled">Hết hàng</div>').show();
		}
	}
	/*begin variant image*/
	if (variant && variant.featured_image) {

		var originalImage = $("#product-featured-image-quickview");
		var newImage = variant.featured_image;
		var element = originalImage[0];
		Haravan.Image.switchImage(newImage, element, function (newImageSizedSrc, newImage, element) {
			$('#thumblist_quickview img').each(function() {
				var parentThumbImg = $(this).parent();
				var productImage = $(this).parent().data("image");
				if (newImageSizedSrc.includes(productImage)) {
					$(this).parent().trigger('click');
					return false;
				}
			});

		});
		$('#product-featured-image-quickview').attr('src',variant.featured_image.src);
	}

	};
</script>
<script defer fetchpriority="low" src="//theme.hstatic.net/200000551679/1001345525/14/quickview.js?v=1469"></script>


<script   src="https://cdn.hstatic.net/shared/api.jquery.js"></script>
<script   src="https://cdn.hstatic.net/shared/option_selection.js"></script>














		<script>
			if (f1genzPS) {
				var cssappend = `<style>
		/* cyrillic-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 300;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fCRc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 300;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fABc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 300;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fCBc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 300;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fBxc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 300;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fCxc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 300;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fChc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 300;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fBBc4AMP6lQ.woff2) format('woff2');
	unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu72xKKTU1Kvnz.woff2) format('woff2');
	unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu5mxKKTU1Kvnz.woff2) format('woff2');
	unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7mxKKTU1Kvnz.woff2) format('woff2');
	unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu4WxKKTU1Kvnz.woff2) format('woff2');
	unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7WxKKTU1Kvnz.woff2) format('woff2');
	unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7GxKKTU1Kvnz.woff2) format('woff2');
	unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu4mxKKTU1Kg.woff2) format('woff2');
	unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 500;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fCRc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 500;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fABc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 500;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fCBc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 500;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fBxc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 500;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fCxc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 500;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fChc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 500;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fBBc4AMP6lQ.woff2) format('woff2');
	unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 700;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCRc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 700;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfABc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 700;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCBc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 700;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfBxc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 700;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCxc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 700;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfChc4AMP6lbBP.woff2) format('woff2');
	unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
	font-family: 'Roboto';
	font-style: normal;
	font-weight: 700;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfBBc4AMP6lQ.woff2) format('woff2');
	unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}

@font-face {
	font-family: 'Yeseva One';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/yesevaone/v15/OpNJno4ck8vc-xYpwWWxliBVWzfAw0blNQ.woff2) format('woff2');
	unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
	font-family: 'Yeseva One';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/yesevaone/v15/OpNJno4ck8vc-xYpwWWxlilVWzfAw0blNQ.woff2) format('woff2');
	unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
	font-family: 'Yeseva One';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/yesevaone/v15/OpNJno4ck8vc-xYpwWWxliJVWzfAw0blNQ.woff2) format('woff2');
	unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
	font-family: 'Yeseva One';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/yesevaone/v15/OpNJno4ck8vc-xYpwWWxliNVWzfAw0blNQ.woff2) format('woff2');
	unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
	font-family: 'Yeseva One';
	font-style: normal;
	font-weight: 400;
	font-display: swap;
	src: url(https://fonts.gstatic.com/s/yesevaone/v15/OpNJno4ck8vc-xYpwWWxli1VWzfAw0Y.woff2) format('woff2');
	unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}</style>`;

				$("head").append(cssappend)
			}


		</script>

		<!--
 Theme Information
 --------------------------------------
 Theme ID: EGA Cosmetic
 Version: v1.2.0_20220408
 Company: EGANY
 changelog: //theme.hstatic.net/200000551679/1001345525/14/ega-changelog.js?v=1469
 ---------------------------------------
 -->
		<script>

			var no_image_placeholder =	"//theme.hstatic.net/200000551679/1001345525/14/no_image.jpg?v=1469"
			window.money_format = '{{amount}}₫';
			var template = '404';

			const campaign_dc = {
				employ: false,
						productHandle: 'phan-qua-dac-biet',
							product: 0,
								price_setup: 29900000
			}

		</script>

		<script>
			if (f1genzPS) {
				!(function (e, s, t) {
					var n = s.getElementsByTagName(t)[0],
							a = s.createElement(t);
					(a.async = !0),
						(a.src = "https://www.googletagmanager.com/gtag/js?id=G-Y8QMNWMMVG"),
						n.parentNode.insertBefore(a, n);
				})(window, document, "script");
			}

			if (f1genzPS) {
				window.dataLayer = window.dataLayer || [];
				function gtag(){dataLayer.push(arguments);}
				gtag('js', new Date());

				gtag('config', 'G-Y8QMNWMMVG');
			}
		</script>
		<!-- Google Tag Manager -->
		<script>
			if (f1genzPS) {
				(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
																											new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
						j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
							'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
														})(window,document,'script','dataLayer','GTM-MR5LCB5');
			}
		</script>
		<!-- End Google Tag Manager -->

		<script src='//theme.hstatic.net/200000551679/1001345525/14/lazysize.js?v=1469' type='text/javascript'></script>

		

		



		<script>
			var checkqia = window.loadquatang = 1;
		</script>




	</head>
	<body  class=" product">
		

		

		<div class="opacity_menu"></div>
		
<div class="top-banner position-relative" style="background: 18a4ea">
	<div class="container text-center px-0" >
				<a class="position-relative  d-sm-none d-block" 
		   style="max-height: 78px;height:  calc( 78 * 100vw /828 )"
		   href="/collections/all" 
		   title="Banner top">
			<img loading="eager" fetchpriority="high" decoding="sync" class='img-fluid position-absolute ' src="//theme.hstatic.net/200000551679/1001345525/14/top_banner_mb.jpg?v=1469" 
				 style="left:0; width: 100%;"
				 alt="Banner top"
				 width="828"
				 height="78"
		
				 >

		</a>
				<a class="position-relative   d-sm-block d-none " 
		   style="max-height: 70px;height:  calc( 70 * 100vw /1410 )"
		   href="/collections/all" 
		   title="Banner top">
			<picture>

				<source media="(max-width: 480px)" srcset="//theme.hstatic.net/200000551679/1001345525/14/top_banner.jpg?v=1469">

				<img loading="eager" fetchpriority="high" decoding="sync" class='img-fluid position-absolute' src="//theme.hstatic.net/200000551679/1001345525/14/top_banner.jpg?v=1469" 
					 style="left:0; width: 100%;"
					 alt="Banner top"
					 width="1410"
					 height="70"
				
					 >
			</picture>

		</a>
		
	</div>

</div>
<script>
	if (f1genzPS) {
	$(document).ready(()=>{
		$('.top-banner .close').click(()=>{
			$('.top-banner').slideToggle()
			sessionStorage.setItem("top-banner",true)
		})


	})
	}
</script>

<header class="header header_menu">
	<div class="mid-header wid_100 d-flex align-items-center">
		<div class="container ">
			<div class="row align-items-center">
				<div class="col-3 header-right d-lg-none d-block">
					<div class="toggle-nav btn menu-bar mr-4 ml-0 p-0  d-lg-none d-flex text-white">
						<span class="bar"></span>
						<span class="bar"></span>
						<span class="bar"></span>
					</div>
				</div>
				<div class="col-6 col-xl-2 col-lg-3 header-left">
										<a href="/" class="logo-wrapper ">	
						<img class="img-fluid"
								 loading="eager" fetchpriority="high" decoding="sync" src="//theme.hstatic.net/200000551679/1001345525/14/logo.png?v=1469" 
								 alt="logo SammiShop"
								 width="248"
								 height="53"
								 >
					</a>
									</div>
				<div class="col-xl-4 col-lg-4 col-12 header-center" id="search-header">
					<div class="f-header-top-search">
	<form action="/search" method="get" class="f-header-top-search input-group search-bar custom-input-group ultimate-search" role="search">
		<input title="seach" type="text" name="q" value="" autocomplete="off" 
					 class="input-group-field auto-search form-control " required="" 
					 data-placeholder="SALE TOÀN NHÃN LÊN ĐẾN 50%; COMBO BÔNG TẨY TRANG GIÁ SIÊU HỜI; HÀNG NGÀN QUÀ TẶNG HẤP DẪN; DEAL ĐỘC QUYỀN CHỈ CÓ TẠI APP/WEB">
		<input type="hidden" name="type" value="product">
		<span class="input-group-btn btn-action">
			<button type="submit"  aria-label="search" class="btn text-white icon-fallback-text h-100">
				<svg class="icon">
	<use xlink:href="#icon-search" />
</svg>			</button>
		</span>

		<div class="search-suggest__wrapper">


		


			<div class="search-wrapper__line search-keyhot">
				<h4>Xu hướng tìm kiếm</h4>
				<ul class="search-keyhot__list">
					
					<li><a href="/collections/kem-chong-nang-sunscreen-1">Kem chống nắng</a></li>
					
					<li><a href="/collections/nuoc-hoa-perfume">Nước hoa</a></li>
					
					<li><a href="/collections/duong-the">Sữa dưỡng thể</a></li>
					
					<li><a href="/collections/son-kem-liquid-lipstick">Son lì</a></li>
					
					<li><a href="/collections/nuoc-hoa-hong-nuoc-can-bang-toner">Toner</a></li>
					
					<li><a href="/collections/mat-na-mask">Mặt nạ</a></li>
					
					<li><a href="/collections/tinh-chat-serum-essence-ampoule">Serum dưỡng trắng</a></li>
					
					<li><a href="/collections/bong-tay-trang-cotton-pads">Bông tẩy trang</a></li>
					
					<li><a href="/collections/phu-kien">Phụ kiện</a></li>
					
					<li><a href="/collections/nuoc-tay-trang">Nước tẩy trang</a></li>
					
					<li><a href="/collections/cham-soc-toc-hair-care">Chăm sóc tóc</a></li>
					
				</ul>
			</div>



			<div class="search-wrapper__line search-brandhot">
				<h4>THƯƠNG HIỆU</h4>
				<ul class="search-brand__list">

					
					<li>
						<a href="https://sammishop.com/collections/dear-klairs">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg1.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/skin1004">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg2.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/beplain">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg3.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/some-by-mi">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg4.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/mediheal">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg5.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/lemonade">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg6.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/wakemake">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg7.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/cosrx">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg8.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/round-lab">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg9.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/instituto-espanol">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg10.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/missha">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg11.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					<li>
						<a href="https://sammishop.com/collections/dr-oracle">
							<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/winfbrandcimg12.png?v=1469" rel="nofollow" />
						</a>
					</li>
					
					
					
					
					
					
					
					
					



				</ul>
			</div>


			<div class="search-wrapper__line search-cate">
				<h4>DANH MỤC NỔI BẬT</h4>
				<ul class="search-cate__list">
					
					<li>
						<a href="https://sammishop.com/pages/deal-sieu-hot">
							🔥DEAL TỐT CHỐT NGAY
						</a>
					</li>
					
					<li>
						<a href="/collections/combo-gia-tot">
							🔥COMBO GIÁ TỐT
						</a>
					</li>
					

				</ul>
			</div>


		</div>





	</form>
	
	<div class="search-overlay"></div>
	</div>														</div>
				<div class="col-3 col-xl-6 col-lg-5 ">
					<ul class="header-right mb-0 float-rightT list-unstyled  d-flex align-items-center">
	<li class='media d-lg-flex d-none hotline'>
		<img loading="lazy"
				 src="//theme.hstatic.net/200000551679/1001345525/14/phone-icon.png?v=1469" 
				 width="32" height="32" class="mr-2 align-self-center" 
				 alt="phone-icon"/>

		<div class="media-body d-md-flex flex-column d-none ">
			<span>Hỗ trợ khách hàng</span>
			<a class="font-weight-bold d-block" href="tel:19002631" title="19002631">
				19002631
			</a>
		</div>
	</li>
	<li class='mx-2 mr-2 mr-md-2 ml-md-2 media d-lg-flex d-none '>
		<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/account-icon.png?v=1469"  width="32" height="32" alt="account-icon"
				 class="mr-2 align-self-center" />
		<div class="media-body d-md-flex flex-column d-none ">
						<a rel="nofollow" href="/account/login"  class="d-block" title="Tài khoản" >
				Tài khoản
			</a>
			<small>
				<a href="/account/login" title="Đăng nhập" class="font-weight: light">
					Đăng nhập
				</a> </small>
			
		</div>
	</li>
	<li class="cartgroup  ml-0 mr-2 mr-md-0">
		<div class="mini-cart text-xs-center">
			<a class="img_hover_cart" href="/cart" title="Giỏ hàng" >  
				<img loading="lazy" src="//theme.hstatic.net/200000551679/1001345525/14/cart-icon.png?v=1469" width="24" height="24" alt="cart-icon"/>

				<span class='mx-2 d-xl-block d-none'>Giỏ hàng</span>
				<span class="count_item count_item_pr">0</span>
			</a>
			<div class="top-cart-content card ">
				<ul id="cart-sidebar" class="mini-products-list count_li list-unstyled">
					<li class="list-item">
						<ul></ul>
					</li>
					<li class="action">

					</li>
				</ul>
			</div>
		</div>
	</li>

		<li class="ml-2 mx-2 media d-lg-flex d-none">
		<div class="">
			<img class="img-fluid mr-2 align-self-center" src="//theme.hstatic.net/200000551679/1001345525/14/policy_header_image_3.png?v=1469"  loading="lazy"  width="32" height="32" alt="Kiểm tra<br>đơn hàng">
		</div>
		<a class="link" href="https://sammishop-2.myharavan.com/pages/kiem-tra-don-hang" title="Kiểm tra<br>đơn hàng">
			Kiểm tra<br>đơn hàng
		</a>
	</li>
		<li class="ml-2 mx-2 media d-lg-flex d-none">
		<div class="">
			<img class="img-fluid mr-2 align-self-center" src="//theme.hstatic.net/200000551679/1001345525/14/policy_header_image_4.png?v=1469"  loading="lazy"  width="32" height="32" alt="Hệ thống<br>cửa hàng">
		</div>
		<a class="link" href="/pages/he-thong-cua-hang" title="Hệ thống<br>cửa hàng">
			Hệ thống<br>cửa hàng
		</a>
	</li>
	</ul>				</div>
			</div>
		</div>
	</div>
</header>
<!-- subheader == mobile nav -->
<div class="menu-new-header">
	<div class="container ">
		<div  class="header-upper-middle  hidden-sm hidden-xs">
			<div class="header-upper-menu">
				<div class="menu-desktop ">	
					<!-- menu nằm tại search.template -->
					<div id="nav-main-menu">
	<!-- menu nằm tại search.template -->
	
</div>



				</div>
			</div>
		</div> 
	</div>
</div>


<script type="text/x-custom-template" data-template="sticky-nav">
	<div class="toogle-nav-wrapper w-100 " >
						<div class=" d-flex align-items-center" style="height: 52px; font-size: 1rem; font-weight: 500">
							<div class="icon-bar btn menu-bar mr-3 ml-0 p-0 d-inline-flex">
							<span class="bar"></span>
							<span class="bar"></span>
							<span class="bar"></span>
	</div>
						Danh mục sản phẩm
	</div>
						<div class="navigation-wrapper">
							<nav class="h-100">
	<ul  class="navigation list-group list-group-flush scroll">
				
		
		
						<li class="menu-item list-group-item">
			<a href="https://sammishop.com/pages/deal-sieu-hot" class="menu-item__link" style="color: #FFF200;font-weight: bold;font-family: sans-serif;" title="SIÊU SALE THÁNG 6">
								<span>SIÊU SALE THÁNG 6</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__item submenu__item--main">
						<a class="link" href="https://sammishop.com/pages/deal-sieu-hot" title="🔥DEAL TỐT CHỐT NGAY">🔥DEAL TỐT CHỐT NGAY</a>
					</li>
					
					

					
					<li class="submenu__item submenu__item--main">
						<a class="link" href="/collections/combo-gia-tot" title="🔥COMBO GIÁ TỐT">🔥COMBO GIÁ TỐT</a>
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/collections/trang-diem" class="menu-item__link"  title="Trang điểm">
								<span>Trang điểm</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/trang-diem-mat" title="Trang điểm mặt">Trang điểm mặt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-lot-primer" title="Kem lót">Kem lót</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-nen-foundation" title="Kem nền">Kem nền</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/phan-nuoc-cushion-1" title="Phấn nước">Phấn nước</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bb-cc-cream" title="BB/CC Cream">BB/CC Cream</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/che-khuyet-diem-concealer" title="Che khuyết điểm">Che khuyết điểm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/tao-khoi-sang-contour-highlight" title="Tạo khối/sáng">Tạo khối/sáng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/phan-ma-blush" title="Phấn má">Phấn má</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/phan-nen-phu-powder" title="Phấn nền/phủ">Phấn nền/phủ</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/xit-khoa-makeup" title="Xịt khóa Makeup">Xịt khóa Makeup</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/trang-diem-moi" title="Trang điểm môi">Trang điểm môi</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/son-kem-liquid-lipstick" title="Son kem">Son kem</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/son-thoi-lipstick" title="Son thỏi">Son thỏi</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/son-duong-lip-balm" title="Son dưỡng">Son dưỡng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/son-lot-lip-filler" title="Son lót">Son lót</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/son-bong" title="Son bóng">Son bóng</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/trang-diem-mat-1" title="Trang điểm mắt">Trang điểm mắt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/chi-ke-may-eyebrow-pencil" title="Chì kẻ mày">Chì kẻ mày</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/phan-mat-eye-shadow" title="Phấn mắt">Phấn mắt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nhu-mat" title="Nhũ mắt">Nhũ mắt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/ke-mat-eyeliner" title="Kẻ mắt">Kẻ mắt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/chuot-mi-mascara" title="Chuốt mi">Chuốt mi</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/dung-cu-trang-diem" title="Dụng cụ trang điểm">Dụng cụ trang điểm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bam-mi" title="Bấm mi">Bấm mi</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/long-mi-gia" title="Lông mi giả">Lông mi giả</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/co-trang-diem-brush" title="Cọ trang điểm">Cọ trang điểm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mut-trang-diem-sponge" title="Mút trang điểm">Mút trang điểm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dung-cu-rua-co" title="Dụng cụ rửa cọ">Dụng cụ rửa cọ</a>
						</span>
						
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/collections/cham-soc-da-skincare" class="menu-item__link"  title="Chăm sóc da">
								<span>Chăm sóc da</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/lam-sach-da" title="Làm sạch da">Làm sạch da</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/sua-rua-mat-cleanser" title="Sữa rửa mặt">Sữa rửa mặt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-tay-trang" title="Dầu tẩy trang">Dầu tẩy trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nuoc-tay-trang" title="Nước tẩy trang">Nước tẩy trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/sap-tay-trang" title="Sáp tẩy trang">Sáp tẩy trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/khan-tay-trang" title="Khăn tẩy trang">Khăn tẩy trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/tay-da-chet-moi" title="Tẩy da chết môi">Tẩy da chết môi</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/tay-da-chet-mat" title="Tẩy da chết mặt">Tẩy da chết mặt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mieng-lot-mun" title="Miếng lột mụn">Miếng lột mụn</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/cham-soc-da-skincare" title="Chăm sóc da">Chăm sóc da</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nuoc-hoa-hong-nuoc-can-bang-toner" title="Nước hoa hồng">Nước hoa hồng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/tinh-chat-serum-essence-ampoule" title="Tinh chất">Tinh chất</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/sua-duong-lotion-emulsion" title="Sữa dưỡng">Sữa dưỡng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-duong-dau-duong-moisturizer" title="Kem dưỡng ẩm">Kem dưỡng ẩm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/duong-mat-eye-cream" title="Kem dưỡng mắt">Kem dưỡng mắt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-tri-mun" title="Kem trị mụn">Kem trị mụn</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/xit-khoang-mineral-water" title="Xịt khoáng">Xịt khoáng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-duong-facial-oil" title="Dầu dưỡng">Dầu dưỡng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bo-duong-da" title="Bộ dưỡng da">Bộ dưỡng da</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/mat-na-mask" title="Mặt nạ">Mặt nạ</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mat-na-giay" title="Mặt nạ giấy">Mặt nạ giấy</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mat-na-ngu" title="Mặt nạ ngủ">Mặt nạ ngủ</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mat-na-rua" title="Mặt nạ rửa">Mặt nạ rửa</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mat-na-moi-1" title="Mặt nạ môi">Mặt nạ môi</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mat-na-mat" title="Mặt nạ mắt">Mặt nạ mắt</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/kem-chong-nang-sunscreen-1" title="Kem chống nắng">Kem chống nắng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-chong-nang-mat" title="Kem chống nắng mặt">Kem chống nắng mặt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-chong-nang-toan-than" title="Kem chống nắng toàn thân">Kem chống nắng toàn thân</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/xit-chong-nang" title="Xịt chống nắng">Xịt chống nắng</a>
						</span>
						
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/collections/cham-soc-co-the-body-care-1" class="menu-item__link"  title="Chăm sóc cơ thể">
								<span>Chăm sóc cơ thể</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/lam-sach-co-the-cleanser" title="Làm sạch cơ thể">Làm sạch cơ thể</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/xa-phong-soap" title="Xà phòng">Xà phòng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/sua-tam-body-wash" title="Sữa tắm">Sữa tắm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/khu-mui" title="Khử mùi">Khử mùi</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/rua-tay-hand-wash" title="Rửa tay">Rửa tay</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-tay-long-hair-removal-cream" title="Kem tẩy lông">Kem tẩy lông</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/tay-da-chet-co-the-scrub-exfoliants" title="Tẩy da chết cơ thể">Tẩy da chết cơ thể</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/cham-soc-co-the-body-care" title="Chăm sóc cơ thể">Chăm sóc cơ thể</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/duong-body-body-lotion" title="Kem dưỡng body">Kem dưỡng body</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/duong-tay-hand-cream" title="Kem dưỡng da tay">Kem dưỡng da tay</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-duong-da-duoi-canh-tay" title="Kem dưỡng da dưới cánh tay">Kem dưỡng da dưới cánh tay</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-duong-da-co" title="Kem dưỡng da cổ">Kem dưỡng da cổ</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-duong-got-chan" title="Kem dưỡng gót chân">Kem dưỡng gót chân</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/tui-u-chan" title="Túi ủ chân">Túi ủ chân</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-duong-facial-oil" title="Dầu dưỡng">Dầu dưỡng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/xit-thom-toan-than-body-mist" title="Xịt thơm toàn thân">Xịt thơm toàn thân</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nuoc-hoa" title="Nước hoa">Nước hoa</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/tay-long" title="Tẩy lông">Tẩy lông</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/dung-cu-cham-soc-co-the-body-tools" title="Dụng cụ chăm sóc cơ thể">Dụng cụ chăm sóc cơ thể</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bam-mong" title="Bấm móng">Bấm móng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dao-cao-chan-may" title="Dao cạo chân mày">Dao cạo chân mày</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dao-cao-long-mat" title="Dao cạo lông mặt">Dao cạo lông mặt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/keo" title="Kéo">Kéo</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dung-cu-cha-got-chan" title="Dụng cụ chà gót chân">Dụng cụ chà gót chân</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nhip" title="Nhíp">Nhíp</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/may-triet-long" title="Máy triệt lông">Máy triệt lông</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/ve-sinh-phu-nu-feminine-products" title="Vệ sinh phụ nữ">Vệ sinh phụ nữ</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dung-dich-ve-sinh" title="Dung dịch vệ sinh">Dung dịch vệ sinh</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bang-ve-sinh" title="Băng vệ sinh">Băng vệ sinh</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nuoc-hoa-vung-kin" title="Nước hoa vùng kín">Nước hoa vùng kín</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/xit-vung-kin" title="Xịt vùng kín">Xịt vùng kín</a>
						</span>
						
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/collections/cham-soc-toc-hair-care" class="menu-item__link"  title="Chăm sóc tóc">
								<span>Chăm sóc tóc</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/lam-sach-toc-1" title="Làm sạch tóc">Làm sạch tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-goi-shampoo" title="Dầu gội">Dầu gội</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/lam-sach-toc" title="Dầu gội khô">Dầu gội khô</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-xa-conditioner" title="Dầu xả">Dầu xả</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/tay-te-bao-chet-da-dau" title="Tẩy tế bào chết da đầu">Tẩy tế bào chết da đầu</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/phuc-hoi-duong-toc-hair-treatment" title="Phục hồi dưỡng tóc">Phục hồi dưỡng tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-u-toc-1" title="Kem ủ tóc">Kem ủ tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mat-na-duong-toc" title="Mặt nạ dưỡng tóc">Mặt nạ dưỡng tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/xit-duong-toc" title="Xịt dưỡng tóc">Xịt dưỡng tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-duong-toc" title="Dầu dưỡng tóc">Dầu dưỡng tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/nhuom-toc" title="Nhuộm tóc">Nhuộm tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/thuoc-nhuom" title="Thuốc nhuộm">Thuốc nhuộm</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/phu-kien-toc" title="Phụ kiện tóc">Phụ kiện tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/day-thun-cot-toc" title="Dây thun cột tóc">Dây thun cột tóc</a>
						</span>
						
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/collections/cham-soc-suc-khoe" class="menu-item__link"  title="Chăm sóc sức khỏe">
								<span>Chăm sóc sức khỏe</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/thuc-pham-chuc-nang" title="Thực phẩm chức năng">Thực phẩm chức năng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/thuc-uong-lam-dep" title="Thức uống làm đẹp">Thức uống làm đẹp</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/thuc-pham-bao-ve-suc-khoe" title="Thực phẩm bảo vệ sức khỏe">Thực phẩm bảo vệ sức khỏe</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/vien-uong-lam-dep" title="Viên uống làm đẹp">Viên uống làm đẹp</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/bao-ve-suc-khoe" title="Bảo vệ sức khỏe">Bảo vệ sức khỏe</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/khau-trang" title="Khẩu trang">Khẩu trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nuoc-gel-rua-tay" title="Nước/ Gel rửa tay">Nước/ Gel rửa tay</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dung-dich-nho-mat" title="Dung dịch nhỏ mắt">Dung dịch nhỏ mắt</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/ke-hoach-hoa-gia-dinh" title="Kế hoạch hóa gia đình">Kế hoạch hóa gia đình</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bao-cao-su" title="Bao cao su">Bao cao su</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/cham-soc-tre-em" title="Chăm sóc trẻ em">Chăm sóc trẻ em</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/khau-trang-tre-em" title="Khẩu trang trẻ em">Khẩu trang trẻ em</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/sua-tam-em-be" title="Sữa tắm em bé">Sữa tắm em bé</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/ban-chai-danh-rang-tre-em" title="Bàn chải đánh răng trẻ em">Bàn chải đánh răng trẻ em</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nuoc-suc-mieng-tre-em" title="Nước súc miệng trẻ em">Nước súc miệng trẻ em</a>
						</span>
						
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/collections/tools-brushes" class="menu-item__link"  title="Tools & Brushes">
								<span>Tools & Brushes</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/dung-cu-trang-diem" title="Dụng cụ trang điểm">Dụng cụ trang điểm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bam-mi" title="Bấm mi">Bấm mi</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/long-mi-gia" title="Lông mi giả">Lông mi giả</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/co-trang-diem-brush" title="Cọ trang điểm">Cọ trang điểm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mut-trang-diem-sponge" title="Mút trang điểm">Mút trang điểm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dung-cu-rua-co" title="Dụng cụ rửa cọ">Dụng cụ rửa cọ</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/dung-cu-cham-soc-da-skincare-tools" title="Dụng cụ chăm sóc da">Dụng cụ chăm sóc da</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/cay-nan-mun" title="Cây nặn mụn">Cây nặn mụn</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/may-rua-mat" title="Máy rửa mặt">Máy rửa mặt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/may-day-tinh-chat" title="Máy đẩy tinh chất">Máy đẩy tinh chất</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/may-hut-mun" title="Máy hút mụn">Máy hút mụn</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/dung-cu-cham-soc-co-the-body-tools" title="Dụng cụ chăm sóc cơ thể">Dụng cụ chăm sóc cơ thể</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/keo" title="Kéo">Kéo</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nhip" title="Nhíp">Nhíp</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bam-mong" title="Bấm móng">Bấm móng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dao-cao-long-mat" title="Dao cạo lông mặt">Dao cạo lông mặt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dao-cao-chan-may" title="Dao cạo chân mày">Dao cạo chân mày</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dung-cu-cha-got-chan" title="Dụng cụ chà gót chân">Dụng cụ chà gót chân</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/may-triet-long" title="Máy triệt lông">Máy triệt lông</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/cham-soc-rang-mieng-oral-care" title="Dụng cụ chăm sóc răng miệng">Dụng cụ chăm sóc răng miệng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kem-danh-rang" title="Kem đánh răng">Kem đánh răng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/ban-chai-danh-rang" title="Bàn chải đánh răng">Bàn chải đánh răng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/ban-chai-dien" title="Bàn chải điện">Bàn chải điện</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nuoc-suc-mieng" title="Nước súc miệng">Nước súc miệng</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/chi-nha-khoa-1" title="Chỉ nha khoa">Chỉ nha khoa</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/may-tam-nuoc" title="Máy tăm nước">Máy tăm nước</a>
						</span>
						
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/collections/phu-kien" class="menu-item__link"  title="Phụ kiện">
								<span>Phụ kiện</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/phu-kien-ca-nhan" title="Phụ kiện cá nhân">Phụ kiện cá nhân</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/quan-lot" title="Quần lót">Quần lót</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mieng-dan-nguc" title="Miếng dán ngực">Miếng dán ngực</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dung-dich-ve-sinh-mieng-dan" title="Dung dịch vệ sinh miếng dán">Dung dịch vệ sinh miếng dán</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/phu-kien-toc" title="Phụ kiện tóc">Phụ kiện tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/day-thun-cot-toc" title="Dây thun cột tóc">Dây thun cột tóc</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/luoc" title="Lược">Lược</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/kep-toc" title="Kẹp tóc">Kẹp tóc</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/khan" title="Khăn">Khăn</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/khan-mat-kho" title="Khăn mặt khô">Khăn mặt khô</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/phu-kien-cham-soc-da" title="Phụ kiện chăm sóc da">Phụ kiện chăm sóc da</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/giay-tham-dau" title="Giấy thấm dầu">Giấy thấm dầu</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mieng-dan-mun" title="Miếng dán mụn">Miếng dán mụn</a>
						</span>
						
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/collections/danh-cho-nam" class="menu-item__link"  title="Dành cho Nam">
								<span>Dành cho Nam</span>
				
				<i class='float-right' data-toggle-submenu>
					

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
				</i>
			</a>			
				
						<div class="submenu scroll">
								<ul class="submenu__list">
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/cham-soc-da-nam" title="Chăm sóc da">Chăm sóc da</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/khan-mat-kho" title="Khăn mặt">Khăn mặt</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mieng-lot-mun" title="Miếng lột mụn">Miếng lột mụn</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/mieng-dan-mun" title="Miếng dán mụn">Miếng dán mụn</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/sua-rua-mat-nam" title="Sữa rửa mặt">Sữa rửa mặt</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/cham-soc-co-the-nam" title="Chăm sóc cơ thể">Chăm sóc cơ thể</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/sua-tam-nam" title="Sữa tắm">Sữa tắm</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/dau-goi-nam-shampoo" title="Dầu gội">Dầu gội</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/khu-mui" title="Khử mùi">Khử mùi</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/nuoc-hoa-nam" title="Nước hoa">Nước hoa</a>
						</span>
						
					</li>
					
					

					
					<li class="submenu__col">
						<span class="submenu__item submenu__item--main">
							<a class="link" href="/collections/ke-hoach-hoa-gia-dinh" title="Kế hoạch hóa gia đình">Kế hoạch hóa gia đình</a>
						</span>
						
						<span class="submenu__item submenu__item">
							<a class="link" href="/collections/bao-cao-su" title="Bao cao su">Bao cao su</a>
						</span>
						
					</li>
					
					
				</ul>
			</div>
					</li>
		
		
		
						<li class="menu-item list-group-item">
			<a href="/pages/tat-ca-thuong-hieu" class="menu-item__link"  title="Tất cả thương hiệu">
								<span>Tất cả thương hiệu</span>
				
			</a>			
				
					</li>
		
	</ul>
</nav>
	</div>
	</div>
					<div class="sticky-overlay"></div>
</script>




<script>
	document.querySelector('.auto-search').addEventListener('focus', function() {
		document.querySelector('.search-suggest__wrapper').style.display = 'block';
	});

	$("body").click(function(e){
		var target = $(e.target);
		var parentUl = target.closest('#search-header').length;
		if(parentUl == 0){
		document.querySelector('.search-suggest__wrapper').style.display = 'none';
		}

	})

</script>





		<section class="page_404 section">
	<div class="container card py-5 mt-4 " >
		<div class="row">
			<div class="col-lg-12">
				<div class="page-404 text-center">
					<img class="img-fluid" src="//theme.hstatic.net/200000551679/1001345525/14/404.png?v=1469" alt="404" width="600" height="264"/>
					<h1 class="title-section-page" style="font-size: 30px; margin-top: 40px">TRANG KHÔNG ĐƯỢC TÌM THẤY</h1>
					<p style="color:#727272">Thật tiếc! Trang của bạn yêu cầu không tồn tại. <br>
						Vui lòng thử với một trang khác hoặc liên hệ để được hỗ trợ nhé!</p>
					<a href="/" class="btn btn-main">Về trang chủ</a>
				</div>
			</div>
		</div>
	</div>
</section> 

		











<footer class="footer bg-white" style="--footer-overlay: #f6f6f6">


	<div class="mid-footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-md-6 col-xl-4 footer-click footer-1">

					<h4 class="title-menu clicked">
						Thông tin liên hệ 
					</h4>
					
					<a href="/" class="logo-wrapper mb-3 d-block ">	
						<img loading="lazy" decoding="async"
								 class="lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/logo-footer.png?v=1469" 
								 alt="logo SammiShop"
								 width="350" 
								 height="100">
					</a>
					
															<p>
						Công ty TNHH Bán lẻ SammiShop.
<br>SammiShop là chuỗi siêu thị mỹ phẩm chính hãng, giá rẻ, đáng tin cậy dành cho giới trẻ Việt Nam.
<br>Giấy chứng nhận đăng ký kinh doanh số 0109129611 cấp ngày 18/03/2020 tại Phòng đăng ký kinh doanh Sở kế hoạch và đầu tư thành phố Hà Nội.
					</p>
															<div class="single-contact">
						<i class="fa fa-map-marker-alt"></i>
						<div class="content">Địa chỉ:
														<span>Số 112 Đường Cầu Giấy, Phường Nghĩa Đô, Thành phố Hà Nội</span>
							
						</div>
					</div>
					<div class="single-contact">
						<i class="fa fa-mobile-alt"></i>
						<div class="content">
							Số điện thoại: <a class="link" title="19002631" href="tel:19002631">19002631</a>
						</div>
					</div>
					<div class="single-contact">
						<i class="fa fa-envelope"></i>
						<div class="content">
							Email: <a title="cskh@sammishop.com" class="link" href="mailto:cskh@sammishop.com">cskh@sammishop.com</a>
						</div>
					</div>
					<div class="social-footer">
						<!--<h4 class="title-menu">
Theo dõi chúng tôi 
</h4>-->
						<ul class="follow_option d-flex flex-wrap align-items-center p-0 list-unstyled">	
							
							<li>
								<a class="facebook link" href="https://www.facebook.com/Sammishop.com86"   target="_blank"
									 title="Theo dõi Facebook SammiShop">
									<img class="lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/facebook.svg?v=1469" loading="lazy" decoding="async" width="24" height="24" alt="facebook"/>	

								</a>
							</li>
							
														
							<li>
								<a class="zalo link" href="https://zalo.me/4034357249438657314" target="_blank" title="Theo dõi zalo SammiShop">
									<img class="lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/zalo.svg?v=1469" loading="lazy" decoding="async" width="24" height="24" alt="zalo"/>	

								</a>
							</li>
							
							
							<li>
								<a class="instgram link" href="https://www.instagram.com/sammishop_official" target="_blank" title="Theo dõi instgram SammiShop">
									<img class="lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/instagram.svg?v=1469"loading="lazy" decoding="async" width="24" height="24" alt="instgram"/>	
								</a>
							</li>
							
							
							<li>
								<a class="shopee link" href="https://shopee.vn/sammishop86" target="_blank" title="Theo dõi shopee SammiShop" onclick="try{window.location.href = 'https://shope.ee/8f1gDVWRoj'}catch(e){}return false">
									<img class="lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/shopee.png?v=1469" loading="lazy" decoding="async" width="24" height="24" alt="shopee"/>	
								</a>
							</li>
							
							
							<li>
								<a class="lazada link" href="https://www.lazada.vn/shop/sammishop-official" target="_blank" title="Theo dõi lazada SammiShop">
									<img class="lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/lazada.png?v=1469" loading="lazy" decoding="async" width="24" height="24" alt="lazada"/>	
								</a>
								
							</li>
							
							
							
							<li>
								<a class="tiktok link" href="https://www.tiktok.com/@sammishop_official" target="_blank" title="Theo dõi tiktok SammiShop">
									<img class="lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/tiktok.png?v=1469" loading="lazy" decoding="async" width="24" height="24" alt="tiktok"/>	
								</a>
							</li>
							
						</ul>
					</div>
									</div>
				<div class="col-xs-12 col-md-6 col-xl-2 footer-click">
					<h4 class="title-menu clicked">
						Về chúng tôi <i class="fa fa-angle-down d-md-none d-inline-block"></i>
					</h4>
					<ul class="list-menu toggle-mn" >
						
						<li class="li_menu">
							<a class="link" href="/pages/cau-chuyen-thuong-hieu" title="Câu chuyện thương hiệu">Câu chuyện thương hiệu</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/pages/dieu-khoan-dich-vu" title="Điều khoản dịch vụ">Điều khoản dịch vụ</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/blogs/tuyen-dung" title="Tuyển dụng">Tuyển dụng</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/pages/he-thong-cua-hang-1" title="Hệ thống cửa hàng">Hệ thống cửa hàng</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="https://sammishop.com/pages/chung-nhan-dai-ly-chinh-hang" title="Chứng nhận đại lý chính hãng">Chứng nhận đại lý chính hãng</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/blogs/chuong-trinh-khuyen-mai" title="Chương trình khuyến mãi">Chương trình khuyến mãi</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/blogs/news" title="Beauty Tips">Beauty Tips</a>
						</li>
						
					</ul>
			
				</div>
				<div class="col-xs-12 col-md-6 col-xl-3 footer-click">
					<h4 class="title-menu clicked">
						Chính sách <i class="fa fa-angle-down d-md-none d-inline-block"></i>
					</h4>
					<ul class="list-menu toggle-mn">
						
						<li class="li_menu">
							<a class="link" href="/pages/huong-dan-mua-hang" title="Hướng dẫn mua hàng">Hướng dẫn mua hàng</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/pages/quy-dinh-va-hinh-thuc-thanh-toan" title="Quy định và hình thức thanh toán">Quy định và hình thức thanh toán</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/pages/chinh-sach-giao-hang" title="Chính sách giao hàng">Chính sách giao hàng</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/pages/chinh-sach-doi-tra" title="Chính sách đổi trả">Chính sách đổi trả</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/pages/chinh-sach-tich-luy-diem" title="Chính sách tích lũy điểm">Chính sách tích lũy điểm</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/pages/chinh-sach-bao-mat" title="Chính sách bảo mật thông tin">Chính sách bảo mật thông tin</a>
						</li>
						
						<li class="li_menu">
							<a class="link" href="/pages/giao-hang-sieu-toc-1h" title="Giao hàng siêu tốc 1H">Giao hàng siêu tốc 1H</a>
						</li>
						
					</ul>
				</div>
				<div class="col-xs-12 col-md-6 col-xl-3 footer-click">
										<h4 class="title-menu">
						Đăng ký nhận tin
					</h4>
					<div class="form_register ">
						<form accept-charset='UTF-8' action='/account/contact' class='contact-form' method='post'>
<input name='form_type' type='hidden' value='customer'>
<input name='utf8' type='hidden' value='✓'>
						<div class="custom-input-group mb-3 form_newsletter form_newsletter_customer" > 						
							<div class="input-group">
								<input type="hidden" id="newsletter-tags" name="contact[tags]" value="khách hàng tiềm năng, bản tin" />     
								<input class="form-control input-group-field " aria-label="Địa chỉ Email" type="email" placeholder="Nhập địa chỉ email"  id="newsletter-email" name="contact[email]"   pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required autocomplete="off" >
								<div class="input-group-btn btn-action">
									<button class="h-100 btn text-white button_subscribe subscribe" type="submit" aria-label="Đăng ký nhận tin" name="subscribe">Đăng ký</button>
								</div>
							</div>
						</div>							
						<div class="sitebox-recaptcha hidden" >
							This site is protected by reCAPTCHA and the Google
							<a href="https://policies.google.com/privacy" target="_blank" rel="noreferrer">Privacy Policy</a> 
							and <a href="https://policies.google.com/terms" target="_blank" rel="noreferrer">Terms of Service</a> apply.
						</div>	


<input name='__RequestVerificationToken' type='hidden' value='CfDJ8FyFPV59mBtNhmQGz0fYZt-3I7QeHowWluJ8tZoUoFrJOYK5mOcOlO9J2o0BS8zBWFhMeJP_AKi3mBNkvcc3hwUzp1kfZM5BbvbdHAo8MPygdhyFaw7p9cVFV8G5IndlDy0l8AyaYiW2w_PsbCwBDxo'>
<input id='8f6a878cae5c442095a72d39bb7ae76d' name='g-recaptcha-response' type='hidden'><noscript src='https://www.google.com/recaptcha/api.js?render=6LchSLkqAAAAABVHBpeFgg8N-WgkYsr5fO6GUF_s'></noscript><noscript>let recaptchaElm=document.getElementById('8f6a878cae5c442095a72d39bb7ae76d');let recaptchaForm=recaptchaElm.parentNode;recaptchaForm.addEventListener("submit",function(formEvent){if(!recaptchaElm.value){formEvent.preventDefault();grecaptcha.ready(function(){grecaptcha.execute('6LchSLkqAAAAABVHBpeFgg8N-WgkYsr5fO6GUF_s',{action:'submit'}).then(function(token){recaptchaElm.value=token;recaptchaForm.requestSubmit(formEvent.submitter)})})}})</noscript></form>

					</div>
					
															<a   target="_blank" href="http://online.gov.vn/(X(1)S(nw5rwqyqsrymwcqhe4uixuv3))/Home/WebDetails/69041?AspxAutoDetectCookieSupport=1" title="Logo bộ công thương"  >
						<img class="lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/logo_bct.png?v=1469" 
								 width="150"
								 height="57"
								 alt="Logo bộ công thương" />
					</a>
										<div class="ft-subscribe">
						<h4 class="title-menu">
							Tải ngay App SammiShop
						</h4>
						<div class="qr-code__group">
							<div class="qr">
								<div class="qr1">
									<img class="dt-width-auto lazyload" width="150" height="150" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/qr_app_downl.png?v=1469" alt="QR Code">
								</div>
								<div class="qr2">
									<img class="dt-width-auto lazyload" width="150" height="150" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/qr_app_downl2.png?v=1469" alt="QR Code">
								</div>
							</div>
							
							<div class="apps">
								<div class="app-store">
									<a href="https://apps.apple.com/vn/app/sammi-shop/id1515882916?l=vi" target="_blank">
										<img class="dt-width-auto lazyload" width="170" height="50" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/appstore_app_downl.png?v=1469" alt="App Store">
									</a>
								</div>
								<div class="gg-play">
									<a href="https://play.google.com/store/apps/details?id=vn.suplo.sammishop" target="_blank">
										<img class="dt-width-auto lazyload" width="170" height="50" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/chplay_app_downl.png?v=1469" alt="Google Play">
									</a>
								</div>
							</div>
						</div>
					</div>
									</div>
			</div>
		</div>
	</div>
	<div class="bg-footer-bottom copyright clearfix py-2">
		<div class="container">
			<div class="row">
				<div id="copyright" class=" col-xl-4 col-lg-12 col-md-12 col-xs-12 fot_copyright">
					<span class="wsp">
						© Bản quyền thuộc về 
						<a href="#" onclick="return false;" 
							 rel="nofollow" 
							 target="_blank">SAMMISHOP</a>
					</span>
				</div>
			</div>

		</div>
	</div>
</footer>


<div class="modal fade" id="ega-modal-banner" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-md align-vertical" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<a href="https://sammishop.com/pages/deal-sieu-hot">
					<img  class="img-fluid lazyload" loading="lazy" decoding="async" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="//theme.hstatic.net/200000551679/1001345525/14/banner_popup_img.png?v=1469" 
							 alt="welcome popup" width="1200" height="1200"/>
				</a>
				<button class="btn-form-close close" type="button" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="ega-modal-fundiin" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-md align-vertical" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<a href="https://fundiin.vn/ecompopup/" target="_blank">
					<img loading="lazy" decoding="async" class="img-fluid" src="https://fundiin.vn/ecom.jpg" alt="fundiin-ecom"/>
				</a>
				<button class="btn-form-close close" type="button" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
			</div>
		</div>
	</div>
</div>

<script type="text/x-custom-template" data-template="navigation">


<nav class="h-100">
<ul  class="navigation list-group list-group-flush scroll">
		
	
	
			<li class="menu-item list-group-item highlight-new">
		<a href="https://sammishop.com/pages/deal-sieu-hot" class="menu-item__link" title="SIÊU SALE THÁNG 6">
						<span>SIÊU SALE THÁNG 6</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>SIÊU SALE THÁNG 6 </span>
				</div>
			
			
			
			<li class="submenu__item submenu__item--main">
					<a class="link" href="https://sammishop.com/pages/deal-sieu-hot" title="🔥DEAL TỐT CHỐT NGAY">🔥DEAL TỐT CHỐT NGAY</a>
				</li>
			
			
			
			
			<li class="submenu__item submenu__item--main">
					<a class="link" href="/collections/combo-gia-tot" title="🔥COMBO GIÁ TỐT">🔥COMBO GIÁ TỐT</a>
				</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/trang-diem" class="menu-item__link" title="Trang điểm">
						<span>Trang điểm</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Trang điểm </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/trang-diem-mat" title="Trang điểm mặt">Trang điểm mặt</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-lot-primer" title="Kem lót">Kem lót</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-nen-foundation" title="Kem nền">Kem nền</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/phan-nuoc-cushion-1" title="Phấn nước">Phấn nước</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bb-cc-cream" title="BB/CC Cream">BB/CC Cream</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/che-khuyet-diem-concealer" title="Che khuyết điểm">Che khuyết điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tao-khoi-sang-contour-highlight" title="Tạo khối/sáng">Tạo khối/sáng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/phan-ma-blush" title="Phấn má">Phấn má</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/phan-nen-phu-powder" title="Phấn nền/phủ">Phấn nền/phủ</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-khoa-makeup" title="Xịt khóa Makeup">Xịt khóa Makeup</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/trang-diem-moi" title="Trang điểm môi">Trang điểm môi</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-kem-liquid-lipstick" title="Son kem">Son kem</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-thoi-lipstick" title="Son thỏi">Son thỏi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-duong-lip-balm" title="Son dưỡng">Son dưỡng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-lot-lip-filler" title="Son lót">Son lót</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-bong" title="Son bóng">Son bóng</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/trang-diem-mat-1" title="Trang điểm mắt">Trang điểm mắt</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/chi-ke-may-eyebrow-pencil" title="Chì kẻ mày">Chì kẻ mày</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/phan-mat-eye-shadow" title="Phấn mắt">Phấn mắt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nhu-mat" title="Nhũ mắt">Nhũ mắt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/ke-mat-eyeliner" title="Kẻ mắt">Kẻ mắt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/chuot-mi-mascara" title="Chuốt mi">Chuốt mi</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-trang-diem" title="Dụng cụ trang điểm">Dụng cụ trang điểm</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bam-mi" title="Bấm mi">Bấm mi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/long-mi-gia" title="Lông mi giả">Lông mi giả</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/co-trang-diem-brush" title="Cọ trang điểm">Cọ trang điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mut-trang-diem-sponge" title="Mút trang điểm">Mút trang điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-cu-rua-co" title="Dụng cụ rửa cọ">Dụng cụ rửa cọ</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/cham-soc-da-skincare" class="menu-item__link" title="Chăm sóc da">
						<span>Chăm sóc da</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Chăm sóc da </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/lam-sach-da" title="Làm sạch da">Làm sạch da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-rua-mat-cleanser" title="Sữa rửa mặt">Sữa rửa mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-tay-trang" title="Dầu tẩy trang">Dầu tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-tay-trang" title="Nước tẩy trang">Nước tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sap-tay-trang" title="Sáp tẩy trang">Sáp tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khan-tay-trang" title="Khăn tẩy trang">Khăn tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-da-chet-moi" title="Tẩy da chết môi">Tẩy da chết môi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-da-chet-mat" title="Tẩy da chết mặt">Tẩy da chết mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-lot-mun" title="Miếng lột mụn">Miếng lột mụn</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-da-skincare" title="Chăm sóc da">Chăm sóc da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-hoa-hong-nuoc-can-bang-toner" title="Nước hoa hồng">Nước hoa hồng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tinh-chat-serum-essence-ampoule" title="Tinh chất">Tinh chất</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-duong-lotion-emulsion" title="Sữa dưỡng">Sữa dưỡng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-duong-dau-duong-moisturizer" title="Kem dưỡng ẩm">Kem dưỡng ẩm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/duong-mat-eye-cream" title="Kem dưỡng mắt">Kem dưỡng mắt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-tri-mun" title="Kem trị mụn">Kem trị mụn</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-khoang-mineral-water" title="Xịt khoáng">Xịt khoáng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-duong-facial-oil" title="Dầu dưỡng">Dầu dưỡng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bo-duong-da" title="Bộ dưỡng da">Bộ dưỡng da</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/mat-na-mask" title="Mặt nạ">Mặt nạ</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-giay" title="Mặt nạ giấy">Mặt nạ giấy</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-ngu" title="Mặt nạ ngủ">Mặt nạ ngủ</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-rua" title="Mặt nạ rửa">Mặt nạ rửa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-moi-1" title="Mặt nạ môi">Mặt nạ môi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-mat" title="Mặt nạ mắt">Mặt nạ mắt</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/kem-chong-nang-sunscreen-1" title="Kem chống nắng">Kem chống nắng</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-chong-nang-mat" title="Kem chống nắng mặt">Kem chống nắng mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-chong-nang-toan-than" title="Kem chống nắng toàn thân">Kem chống nắng toàn thân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-chong-nang" title="Xịt chống nắng">Xịt chống nắng</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/cham-soc-co-the-body-care-1" class="menu-item__link" title="Chăm sóc cơ thể">
						<span>Chăm sóc cơ thể</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Chăm sóc cơ thể </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/lam-sach-co-the-cleanser" title="Làm sạch cơ thể">Làm sạch cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xa-phong-soap" title="Xà phòng">Xà phòng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-tam-body-wash" title="Sữa tắm">Sữa tắm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khu-mui" title="Khử mùi">Khử mùi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/rua-tay-hand-wash" title="Rửa tay">Rửa tay</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-tay-long-hair-removal-cream" title="Kem tẩy lông">Kem tẩy lông</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-da-chet-co-the-scrub-exfoliants" title="Tẩy da chết cơ thể">Tẩy da chết cơ thể</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-co-the-body-care" title="Chăm sóc cơ thể">Chăm sóc cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/duong-body-body-lotion" title="Kem dưỡng body">Kem dưỡng body</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/duong-tay-hand-cream" title="Kem dưỡng da tay">Kem dưỡng da tay</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-duong-da-duoi-canh-tay" title="Kem dưỡng da dưới cánh tay">Kem dưỡng da dưới cánh tay</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-duong-da-co" title="Kem dưỡng da cổ">Kem dưỡng da cổ</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-duong-got-chan" title="Kem dưỡng gót chân">Kem dưỡng gót chân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tui-u-chan" title="Túi ủ chân">Túi ủ chân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-duong-facial-oil" title="Dầu dưỡng">Dầu dưỡng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-thom-toan-than-body-mist" title="Xịt thơm toàn thân">Xịt thơm toàn thân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-hoa" title="Nước hoa">Nước hoa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-long" title="Tẩy lông">Tẩy lông</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-cham-soc-co-the-body-tools" title="Dụng cụ chăm sóc cơ thể">Dụng cụ chăm sóc cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bam-mong" title="Bấm móng">Bấm móng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dao-cao-chan-may" title="Dao cạo chân mày">Dao cạo chân mày</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dao-cao-long-mat" title="Dao cạo lông mặt">Dao cạo lông mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/keo" title="Kéo">Kéo</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-cu-cha-got-chan" title="Dụng cụ chà gót chân">Dụng cụ chà gót chân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nhip" title="Nhíp">Nhíp</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-triet-long" title="Máy triệt lông">Máy triệt lông</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/ve-sinh-phu-nu-feminine-products" title="Vệ sinh phụ nữ">Vệ sinh phụ nữ</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-dich-ve-sinh" title="Dung dịch vệ sinh">Dung dịch vệ sinh</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bang-ve-sinh" title="Băng vệ sinh">Băng vệ sinh</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-hoa-vung-kin" title="Nước hoa vùng kín">Nước hoa vùng kín</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-vung-kin" title="Xịt vùng kín">Xịt vùng kín</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/cham-soc-toc-hair-care" class="menu-item__link" title="Chăm sóc tóc">
						<span>Chăm sóc tóc</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Chăm sóc tóc </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/lam-sach-toc-1" title="Làm sạch tóc">Làm sạch tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-goi-shampoo" title="Dầu gội">Dầu gội</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/lam-sach-toc" title="Dầu gội khô">Dầu gội khô</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-xa-conditioner" title="Dầu xả">Dầu xả</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-te-bao-chet-da-dau" title="Tẩy tế bào chết da đầu">Tẩy tế bào chết da đầu</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phuc-hoi-duong-toc-hair-treatment" title="Phục hồi dưỡng tóc">Phục hồi dưỡng tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-u-toc-1" title="Kem ủ tóc">Kem ủ tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-duong-toc" title="Mặt nạ dưỡng tóc">Mặt nạ dưỡng tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-duong-toc" title="Xịt dưỡng tóc">Xịt dưỡng tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-duong-toc" title="Dầu dưỡng tóc">Dầu dưỡng tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/nhuom-toc" title="Nhuộm tóc">Nhuộm tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/thuoc-nhuom" title="Thuốc nhuộm">Thuốc nhuộm</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phu-kien-toc" title="Phụ kiện tóc">Phụ kiện tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/day-thun-cot-toc" title="Dây thun cột tóc">Dây thun cột tóc</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/cham-soc-suc-khoe" class="menu-item__link" title="Chăm sóc sức khỏe">
						<span>Chăm sóc sức khỏe</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Chăm sóc sức khỏe </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/thuc-pham-chuc-nang" title="Thực phẩm chức năng">Thực phẩm chức năng</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/thuc-uong-lam-dep" title="Thức uống làm đẹp">Thức uống làm đẹp</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/thuc-pham-bao-ve-suc-khoe" title="Thực phẩm bảo vệ sức khỏe">Thực phẩm bảo vệ sức khỏe</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/vien-uong-lam-dep" title="Viên uống làm đẹp">Viên uống làm đẹp</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/bao-ve-suc-khoe" title="Bảo vệ sức khỏe">Bảo vệ sức khỏe</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khau-trang" title="Khẩu trang">Khẩu trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-gel-rua-tay" title="Nước/ Gel rửa tay">Nước/ Gel rửa tay</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-dich-nho-mat" title="Dung dịch nhỏ mắt">Dung dịch nhỏ mắt</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/ke-hoach-hoa-gia-dinh" title="Kế hoạch hóa gia đình">Kế hoạch hóa gia đình</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bao-cao-su" title="Bao cao su">Bao cao su</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-tre-em" title="Chăm sóc trẻ em">Chăm sóc trẻ em</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khau-trang-tre-em" title="Khẩu trang trẻ em">Khẩu trang trẻ em</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-tam-em-be" title="Sữa tắm em bé">Sữa tắm em bé</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/ban-chai-danh-rang-tre-em" title="Bàn chải đánh răng trẻ em">Bàn chải đánh răng trẻ em</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-suc-mieng-tre-em" title="Nước súc miệng trẻ em">Nước súc miệng trẻ em</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/tools-brushes" class="menu-item__link" title="Tools & Brushes">
						<span>Tools & Brushes</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Tools & Brushes </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-trang-diem" title="Dụng cụ trang điểm">Dụng cụ trang điểm</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bam-mi" title="Bấm mi">Bấm mi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/long-mi-gia" title="Lông mi giả">Lông mi giả</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/co-trang-diem-brush" title="Cọ trang điểm">Cọ trang điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mut-trang-diem-sponge" title="Mút trang điểm">Mút trang điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-cu-rua-co" title="Dụng cụ rửa cọ">Dụng cụ rửa cọ</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-cham-soc-da-skincare-tools" title="Dụng cụ chăm sóc da">Dụng cụ chăm sóc da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/cay-nan-mun" title="Cây nặn mụn">Cây nặn mụn</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-rua-mat" title="Máy rửa mặt">Máy rửa mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-day-tinh-chat" title="Máy đẩy tinh chất">Máy đẩy tinh chất</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-hut-mun" title="Máy hút mụn">Máy hút mụn</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-cham-soc-co-the-body-tools" title="Dụng cụ chăm sóc cơ thể">Dụng cụ chăm sóc cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/keo" title="Kéo">Kéo</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nhip" title="Nhíp">Nhíp</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bam-mong" title="Bấm móng">Bấm móng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dao-cao-long-mat" title="Dao cạo lông mặt">Dao cạo lông mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dao-cao-chan-may" title="Dao cạo chân mày">Dao cạo chân mày</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-cu-cha-got-chan" title="Dụng cụ chà gót chân">Dụng cụ chà gót chân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-triet-long" title="Máy triệt lông">Máy triệt lông</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-rang-mieng-oral-care" title="Dụng cụ chăm sóc răng miệng">Dụng cụ chăm sóc răng miệng</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-danh-rang" title="Kem đánh răng">Kem đánh răng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/ban-chai-danh-rang" title="Bàn chải đánh răng">Bàn chải đánh răng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/ban-chai-dien" title="Bàn chải điện">Bàn chải điện</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-suc-mieng" title="Nước súc miệng">Nước súc miệng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/chi-nha-khoa-1" title="Chỉ nha khoa">Chỉ nha khoa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-tam-nuoc" title="Máy tăm nước">Máy tăm nước</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/phu-kien" class="menu-item__link" title="Phụ kiện">
						<span>Phụ kiện</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Phụ kiện </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phu-kien-ca-nhan" title="Phụ kiện cá nhân">Phụ kiện cá nhân</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/quan-lot" title="Quần lót">Quần lót</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-dan-nguc" title="Miếng dán ngực">Miếng dán ngực</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-dich-ve-sinh-mieng-dan" title="Dung dịch vệ sinh miếng dán">Dung dịch vệ sinh miếng dán</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phu-kien-toc" title="Phụ kiện tóc">Phụ kiện tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/day-thun-cot-toc" title="Dây thun cột tóc">Dây thun cột tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/luoc" title="Lược">Lược</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kep-toc" title="Kẹp tóc">Kẹp tóc</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/khan" title="Khăn">Khăn</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khan-mat-kho" title="Khăn mặt khô">Khăn mặt khô</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phu-kien-cham-soc-da" title="Phụ kiện chăm sóc da">Phụ kiện chăm sóc da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/giay-tham-dau" title="Giấy thấm dầu">Giấy thấm dầu</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-dan-mun" title="Miếng dán mụn">Miếng dán mụn</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/danh-cho-nam" class="menu-item__link" title="Dành cho Nam">
						<span>Dành cho Nam</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Dành cho Nam </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-da-nam" title="Chăm sóc da">Chăm sóc da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khan-mat-kho" title="Khăn mặt">Khăn mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-lot-mun" title="Miếng lột mụn">Miếng lột mụn</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-dan-mun" title="Miếng dán mụn">Miếng dán mụn</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-rua-mat-nam" title="Sữa rửa mặt">Sữa rửa mặt</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-co-the-nam" title="Chăm sóc cơ thể">Chăm sóc cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-tam-nam" title="Sữa tắm">Sữa tắm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-goi-nam-shampoo" title="Dầu gội">Dầu gội</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khu-mui" title="Khử mùi">Khử mùi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-hoa-nam" title="Nước hoa">Nước hoa</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/ke-hoach-hoa-gia-dinh" title="Kế hoạch hóa gia đình">Kế hoạch hóa gia đình</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bao-cao-su" title="Bao cao su">Bao cao su</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/pages/tat-ca-thuong-hieu" class="menu-item__link" title="Tất cả thương hiệu">
						<span>Tất cả thương hiệu</span>
			
			</a>			
			
			</li>
	
</ul>
</nav>
 
</script>

<script type="text/x-custom-template" data-template="menuMobile">
<div id="mobile-menu" class="scroll">
	<button  class='close menu-close-btn'>
<span aria-hidden="true">✕</span>
</button>
	<div class='media d-flex user-menu'>

		<i class="fas fa-user-circle mr-3 align-self-center"></i>
		<div class="media-body d-md-flex flex-column ">
						<a rel="nofollow" href="/account/login" class="d-block" title="Tài khoản" >
				Tài khoản
			</a>
			<small>
				<a href="/account/login" title="Đăng nhập" class="font-weight: light">
					Đăng nhập
				</a> </small>
			
		</div>
	</div>
	<div class="mobile-menu-body scroll">
			
<nav class="h-100">
<ul  class="navigation list-group list-group-flush scroll">
		
	
	
			<li class="menu-item list-group-item highlight-new">
		<a href="https://sammishop.com/pages/deal-sieu-hot" class="menu-item__link" title="SIÊU SALE THÁNG 6">
						<span>SIÊU SALE THÁNG 6</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>SIÊU SALE THÁNG 6 </span>
				</div>
			
			
			
			<li class="submenu__item submenu__item--main">
					<a class="link" href="https://sammishop.com/pages/deal-sieu-hot" title="🔥DEAL TỐT CHỐT NGAY">🔥DEAL TỐT CHỐT NGAY</a>
				</li>
			
			
			
			
			<li class="submenu__item submenu__item--main">
					<a class="link" href="/collections/combo-gia-tot" title="🔥COMBO GIÁ TỐT">🔥COMBO GIÁ TỐT</a>
				</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/trang-diem" class="menu-item__link" title="Trang điểm">
						<span>Trang điểm</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Trang điểm </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/trang-diem-mat" title="Trang điểm mặt">Trang điểm mặt</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-lot-primer" title="Kem lót">Kem lót</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-nen-foundation" title="Kem nền">Kem nền</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/phan-nuoc-cushion-1" title="Phấn nước">Phấn nước</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bb-cc-cream" title="BB/CC Cream">BB/CC Cream</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/che-khuyet-diem-concealer" title="Che khuyết điểm">Che khuyết điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tao-khoi-sang-contour-highlight" title="Tạo khối/sáng">Tạo khối/sáng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/phan-ma-blush" title="Phấn má">Phấn má</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/phan-nen-phu-powder" title="Phấn nền/phủ">Phấn nền/phủ</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-khoa-makeup" title="Xịt khóa Makeup">Xịt khóa Makeup</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/trang-diem-moi" title="Trang điểm môi">Trang điểm môi</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-kem-liquid-lipstick" title="Son kem">Son kem</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-thoi-lipstick" title="Son thỏi">Son thỏi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-duong-lip-balm" title="Son dưỡng">Son dưỡng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-lot-lip-filler" title="Son lót">Son lót</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/son-bong" title="Son bóng">Son bóng</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/trang-diem-mat-1" title="Trang điểm mắt">Trang điểm mắt</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/chi-ke-may-eyebrow-pencil" title="Chì kẻ mày">Chì kẻ mày</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/phan-mat-eye-shadow" title="Phấn mắt">Phấn mắt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nhu-mat" title="Nhũ mắt">Nhũ mắt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/ke-mat-eyeliner" title="Kẻ mắt">Kẻ mắt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/chuot-mi-mascara" title="Chuốt mi">Chuốt mi</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-trang-diem" title="Dụng cụ trang điểm">Dụng cụ trang điểm</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bam-mi" title="Bấm mi">Bấm mi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/long-mi-gia" title="Lông mi giả">Lông mi giả</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/co-trang-diem-brush" title="Cọ trang điểm">Cọ trang điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mut-trang-diem-sponge" title="Mút trang điểm">Mút trang điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-cu-rua-co" title="Dụng cụ rửa cọ">Dụng cụ rửa cọ</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/cham-soc-da-skincare" class="menu-item__link" title="Chăm sóc da">
						<span>Chăm sóc da</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Chăm sóc da </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/lam-sach-da" title="Làm sạch da">Làm sạch da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-rua-mat-cleanser" title="Sữa rửa mặt">Sữa rửa mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-tay-trang" title="Dầu tẩy trang">Dầu tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-tay-trang" title="Nước tẩy trang">Nước tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sap-tay-trang" title="Sáp tẩy trang">Sáp tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khan-tay-trang" title="Khăn tẩy trang">Khăn tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-da-chet-moi" title="Tẩy da chết môi">Tẩy da chết môi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-da-chet-mat" title="Tẩy da chết mặt">Tẩy da chết mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-lot-mun" title="Miếng lột mụn">Miếng lột mụn</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-da-skincare" title="Chăm sóc da">Chăm sóc da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-hoa-hong-nuoc-can-bang-toner" title="Nước hoa hồng">Nước hoa hồng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tinh-chat-serum-essence-ampoule" title="Tinh chất">Tinh chất</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-duong-lotion-emulsion" title="Sữa dưỡng">Sữa dưỡng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-duong-dau-duong-moisturizer" title="Kem dưỡng ẩm">Kem dưỡng ẩm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/duong-mat-eye-cream" title="Kem dưỡng mắt">Kem dưỡng mắt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-tri-mun" title="Kem trị mụn">Kem trị mụn</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-khoang-mineral-water" title="Xịt khoáng">Xịt khoáng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-duong-facial-oil" title="Dầu dưỡng">Dầu dưỡng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bo-duong-da" title="Bộ dưỡng da">Bộ dưỡng da</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/mat-na-mask" title="Mặt nạ">Mặt nạ</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-giay" title="Mặt nạ giấy">Mặt nạ giấy</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-ngu" title="Mặt nạ ngủ">Mặt nạ ngủ</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-rua" title="Mặt nạ rửa">Mặt nạ rửa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-moi-1" title="Mặt nạ môi">Mặt nạ môi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-mat" title="Mặt nạ mắt">Mặt nạ mắt</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/kem-chong-nang-sunscreen-1" title="Kem chống nắng">Kem chống nắng</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-chong-nang-mat" title="Kem chống nắng mặt">Kem chống nắng mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-chong-nang-toan-than" title="Kem chống nắng toàn thân">Kem chống nắng toàn thân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-chong-nang" title="Xịt chống nắng">Xịt chống nắng</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/cham-soc-co-the-body-care-1" class="menu-item__link" title="Chăm sóc cơ thể">
						<span>Chăm sóc cơ thể</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Chăm sóc cơ thể </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/lam-sach-co-the-cleanser" title="Làm sạch cơ thể">Làm sạch cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xa-phong-soap" title="Xà phòng">Xà phòng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-tam-body-wash" title="Sữa tắm">Sữa tắm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khu-mui" title="Khử mùi">Khử mùi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/rua-tay-hand-wash" title="Rửa tay">Rửa tay</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-tay-long-hair-removal-cream" title="Kem tẩy lông">Kem tẩy lông</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-da-chet-co-the-scrub-exfoliants" title="Tẩy da chết cơ thể">Tẩy da chết cơ thể</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-co-the-body-care" title="Chăm sóc cơ thể">Chăm sóc cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/duong-body-body-lotion" title="Kem dưỡng body">Kem dưỡng body</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/duong-tay-hand-cream" title="Kem dưỡng da tay">Kem dưỡng da tay</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-duong-da-duoi-canh-tay" title="Kem dưỡng da dưới cánh tay">Kem dưỡng da dưới cánh tay</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-duong-da-co" title="Kem dưỡng da cổ">Kem dưỡng da cổ</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-duong-got-chan" title="Kem dưỡng gót chân">Kem dưỡng gót chân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tui-u-chan" title="Túi ủ chân">Túi ủ chân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-duong-facial-oil" title="Dầu dưỡng">Dầu dưỡng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-thom-toan-than-body-mist" title="Xịt thơm toàn thân">Xịt thơm toàn thân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-hoa" title="Nước hoa">Nước hoa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-long" title="Tẩy lông">Tẩy lông</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-cham-soc-co-the-body-tools" title="Dụng cụ chăm sóc cơ thể">Dụng cụ chăm sóc cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bam-mong" title="Bấm móng">Bấm móng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dao-cao-chan-may" title="Dao cạo chân mày">Dao cạo chân mày</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dao-cao-long-mat" title="Dao cạo lông mặt">Dao cạo lông mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/keo" title="Kéo">Kéo</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-cu-cha-got-chan" title="Dụng cụ chà gót chân">Dụng cụ chà gót chân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nhip" title="Nhíp">Nhíp</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-triet-long" title="Máy triệt lông">Máy triệt lông</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/ve-sinh-phu-nu-feminine-products" title="Vệ sinh phụ nữ">Vệ sinh phụ nữ</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-dich-ve-sinh" title="Dung dịch vệ sinh">Dung dịch vệ sinh</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bang-ve-sinh" title="Băng vệ sinh">Băng vệ sinh</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-hoa-vung-kin" title="Nước hoa vùng kín">Nước hoa vùng kín</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-vung-kin" title="Xịt vùng kín">Xịt vùng kín</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/cham-soc-toc-hair-care" class="menu-item__link" title="Chăm sóc tóc">
						<span>Chăm sóc tóc</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Chăm sóc tóc </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/lam-sach-toc-1" title="Làm sạch tóc">Làm sạch tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-goi-shampoo" title="Dầu gội">Dầu gội</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/lam-sach-toc" title="Dầu gội khô">Dầu gội khô</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-xa-conditioner" title="Dầu xả">Dầu xả</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/tay-te-bao-chet-da-dau" title="Tẩy tế bào chết da đầu">Tẩy tế bào chết da đầu</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phuc-hoi-duong-toc-hair-treatment" title="Phục hồi dưỡng tóc">Phục hồi dưỡng tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-u-toc-1" title="Kem ủ tóc">Kem ủ tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mat-na-duong-toc" title="Mặt nạ dưỡng tóc">Mặt nạ dưỡng tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/xit-duong-toc" title="Xịt dưỡng tóc">Xịt dưỡng tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-duong-toc" title="Dầu dưỡng tóc">Dầu dưỡng tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-dua" title="Dầu dừa">Dầu dừa</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/nhuom-toc" title="Nhuộm tóc">Nhuộm tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/thuoc-nhuom" title="Thuốc nhuộm">Thuốc nhuộm</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phu-kien-toc" title="Phụ kiện tóc">Phụ kiện tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/day-thun-cot-toc" title="Dây thun cột tóc">Dây thun cột tóc</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/cham-soc-suc-khoe" class="menu-item__link" title="Chăm sóc sức khỏe">
						<span>Chăm sóc sức khỏe</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Chăm sóc sức khỏe </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/thuc-pham-chuc-nang" title="Thực phẩm chức năng">Thực phẩm chức năng</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/thuc-uong-lam-dep" title="Thức uống làm đẹp">Thức uống làm đẹp</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/thuc-pham-bao-ve-suc-khoe" title="Thực phẩm bảo vệ sức khỏe">Thực phẩm bảo vệ sức khỏe</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/vien-uong-lam-dep" title="Viên uống làm đẹp">Viên uống làm đẹp</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/bao-ve-suc-khoe" title="Bảo vệ sức khỏe">Bảo vệ sức khỏe</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khau-trang" title="Khẩu trang">Khẩu trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-gel-rua-tay" title="Nước/ Gel rửa tay">Nước/ Gel rửa tay</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-dich-nho-mat" title="Dung dịch nhỏ mắt">Dung dịch nhỏ mắt</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/ke-hoach-hoa-gia-dinh" title="Kế hoạch hóa gia đình">Kế hoạch hóa gia đình</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bao-cao-su" title="Bao cao su">Bao cao su</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-tre-em" title="Chăm sóc trẻ em">Chăm sóc trẻ em</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khau-trang-tre-em" title="Khẩu trang trẻ em">Khẩu trang trẻ em</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-tam-em-be" title="Sữa tắm em bé">Sữa tắm em bé</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/ban-chai-danh-rang-tre-em" title="Bàn chải đánh răng trẻ em">Bàn chải đánh răng trẻ em</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-suc-mieng-tre-em" title="Nước súc miệng trẻ em">Nước súc miệng trẻ em</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/tools-brushes" class="menu-item__link" title="Tools & Brushes">
						<span>Tools & Brushes</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Tools & Brushes </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-trang-diem" title="Dụng cụ trang điểm">Dụng cụ trang điểm</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bam-mi" title="Bấm mi">Bấm mi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/long-mi-gia" title="Lông mi giả">Lông mi giả</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/co-trang-diem-brush" title="Cọ trang điểm">Cọ trang điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mut-trang-diem-sponge" title="Mút trang điểm">Mút trang điểm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-cu-rua-co" title="Dụng cụ rửa cọ">Dụng cụ rửa cọ</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-cham-soc-da-skincare-tools" title="Dụng cụ chăm sóc da">Dụng cụ chăm sóc da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bong-tay-trang-cotton-pads" title="Bông tẩy trang">Bông tẩy trang</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/cay-nan-mun" title="Cây nặn mụn">Cây nặn mụn</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-rua-mat" title="Máy rửa mặt">Máy rửa mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-day-tinh-chat" title="Máy đẩy tinh chất">Máy đẩy tinh chất</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-hut-mun" title="Máy hút mụn">Máy hút mụn</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/dung-cu-cham-soc-co-the-body-tools" title="Dụng cụ chăm sóc cơ thể">Dụng cụ chăm sóc cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/keo" title="Kéo">Kéo</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nhip" title="Nhíp">Nhíp</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bam-mong" title="Bấm móng">Bấm móng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dao-cao-long-mat" title="Dao cạo lông mặt">Dao cạo lông mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dao-cao-chan-may" title="Dao cạo chân mày">Dao cạo chân mày</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-cu-cha-got-chan" title="Dụng cụ chà gót chân">Dụng cụ chà gót chân</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-triet-long" title="Máy triệt lông">Máy triệt lông</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-rang-mieng-oral-care" title="Dụng cụ chăm sóc răng miệng">Dụng cụ chăm sóc răng miệng</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kem-danh-rang" title="Kem đánh răng">Kem đánh răng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/ban-chai-danh-rang" title="Bàn chải đánh răng">Bàn chải đánh răng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/ban-chai-dien" title="Bàn chải điện">Bàn chải điện</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-suc-mieng" title="Nước súc miệng">Nước súc miệng</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/chi-nha-khoa-1" title="Chỉ nha khoa">Chỉ nha khoa</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/may-tam-nuoc" title="Máy tăm nước">Máy tăm nước</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/phu-kien" class="menu-item__link" title="Phụ kiện">
						<span>Phụ kiện</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Phụ kiện </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phu-kien-ca-nhan" title="Phụ kiện cá nhân">Phụ kiện cá nhân</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/quan-lot" title="Quần lót">Quần lót</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-dan-nguc" title="Miếng dán ngực">Miếng dán ngực</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dung-dich-ve-sinh-mieng-dan" title="Dung dịch vệ sinh miếng dán">Dung dịch vệ sinh miếng dán</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phu-kien-toc" title="Phụ kiện tóc">Phụ kiện tóc</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/day-thun-cot-toc" title="Dây thun cột tóc">Dây thun cột tóc</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/luoc" title="Lược">Lược</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/kep-toc" title="Kẹp tóc">Kẹp tóc</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/khan" title="Khăn">Khăn</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khan-mat-kho" title="Khăn mặt khô">Khăn mặt khô</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/phu-kien-cham-soc-da" title="Phụ kiện chăm sóc da">Phụ kiện chăm sóc da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/giay-tham-dau" title="Giấy thấm dầu">Giấy thấm dầu</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-dan-mun" title="Miếng dán mụn">Miếng dán mụn</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/collections/danh-cho-nam" class="menu-item__link" title="Dành cho Nam">
						<span>Dành cho Nam</span>
			
			<i class='float-right' data-toggle-submenu>
			

<svg class="icon" >
	<use xlink:href="#icon-arrow" />
</svg>
			</i>
			</a>			
			
				<div class="submenu scroll">
						<ul class="submenu__list">
					<div class='toggle-submenu'>
					<i class='mr-3'>
						

<svg class="icon" style="transform: rotate(180deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
					</i>
					<span>Dành cho Nam </span>
				</div>
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-da-nam" title="Chăm sóc da">Chăm sóc da</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khan-mat-kho" title="Khăn mặt">Khăn mặt</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-lot-mun" title="Miếng lột mụn">Miếng lột mụn</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/mieng-dan-mun" title="Miếng dán mụn">Miếng dán mụn</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-rua-mat-nam" title="Sữa rửa mặt">Sữa rửa mặt</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/cham-soc-co-the-nam" title="Chăm sóc cơ thể">Chăm sóc cơ thể</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/sua-tam-nam" title="Sữa tắm">Sữa tắm</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/dau-goi-nam-shampoo" title="Dầu gội">Dầu gội</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/khu-mui" title="Khử mùi">Khử mùi</a>
				 </span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/nuoc-hoa-nam" title="Nước hoa">Nước hoa</a>
				 </span>
				
			</li>
			
			
			
			
			<li class="submenu__col">
				<span class="submenu__item submenu__item--main">
					<a class="link" href="/collections/ke-hoach-hoa-gia-dinh" title="Kế hoạch hóa gia đình">Kế hoạch hóa gia đình</a>
				</span>
				
				 <span class="submenu__item submenu__item">
					 <a class="link" href="/collections/bao-cao-su" title="Bao cao su">Bao cao su</a>
				 </span>
				
			</li>
			
			
		</ul>
		</div>
			</li>
	
	
	
			<li class="menu-item list-group-item ">
		<a href="/pages/tat-ca-thuong-hieu" class="menu-item__link" title="Tất cả thương hiệu">
						<span>Tất cả thương hiệu</span>
			
			</a>			
			
			</li>
	
</ul>
</nav>

		<ul class="shop-policises list-unstyled  d-flex align-items-center flex-wrap m-0 pr-0">
													<li>
		<div class="">
			<img class="img-fluid " 
					 src="//theme.hstatic.net/200000551679/1001345525/14/policy_header_image_3.png?v=1469" 
					 loading="lazy"
					 width="32"
					 height="32"
					 alt="Kiểm tra<br>đơn hàng">
		</div>
		<a class="link" href="https://sammishop-2.myharavan.com/pages/kiem-tra-don-hang" title="Kiểm tra<br>đơn hàng">Kiểm tra đơn hàng</a>
	</li>
								<li>
		<div class="">
			<img class="img-fluid " 
					 src="//theme.hstatic.net/200000551679/1001345525/14/policy_header_image_4.png?v=1469" 
					 loading="lazy"
					 width="32"
					 height="32"
					 alt="Hệ thống<br>cửa hàng">
		</div>
		<a class="link" href="/pages/he-thong-cua-hang" title="Hệ thống<br>cửa hàng">Hệ thống cửa hàng</a>
	</li>
		
</ul>	</div>

	<div class="mobile-menu-footer border-top w-100 d-flex align-items-center text-center">
		<div class="hotline  w-50   p-2 ">
			<a  href="tel:19002631" title="19002631">
				Gọi điện <i class="fas fa-phone ml-3"></i>
			</a>
		</div>
				<div class="messenger border-left p-2 w-50 border-left">
						
			<a  href="https://m.me/Sammishop.com86" title="https://m.me/Sammishop.com86">
				Nhắn tin
				<i class="fab fa-facebook-messenger ml-3"></i>
			</a>
		</div>
		
	</div>
</div>
<div class='menu-overlay'>

</div>
</script>
		<svg style="display:none">
  <defs>
<symbol class="icon " id="icon-cart" viewBox="0 0 16 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.594 16.39a.703.703 0 0 1-.703.704h-.704v.703a.703.703 0 0 1-1.406 0v-.703h-.703a.703.703 0 0 1 0-1.407h.703v-.703a.703.703 0 1 1 1.406 0v.704h.704c.388 0 .703.314.703.703Zm0-10.968v6.75a.703.703 0 0 1-1.406 0V6.125H12.78v2.11a.703.703 0 1 1-1.406 0v-2.11h-6.75v2.11a.703.703 0 1 1-1.406 0v-2.11H1.813v10.969h7.453a.703.703 0 1 1 0 1.406H1.109a.703.703 0 0 1-.703-.703V5.422c0-.388.315-.703.703-.703h2.143A4.788 4.788 0 0 1 8 .5a4.788 4.788 0 0 1 4.748 4.219h2.143c.388 0 .703.315.703.703Zm-4.266-.703A3.38 3.38 0 0 0 8 1.906 3.38 3.38 0 0 0 4.672 4.72h6.656Z" fill="currentColor"/></symbol>
	</defs>
</svg>
<svg style="display:none">
  <defs>
<symbol id="icon-minus" class="icon icon-minus" viewBox="0 0 16 2" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M15.375 0H0.625C0.279813 0 0 0.279813 0 0.625C0 0.970187 0.279813 1.25 0.625 1.25H15.375C15.7202 1.25 16 0.970187 16 0.625C16 0.279813 15.7202 0 15.375 0Z" fill="#8C9196"/>
</symbol>
	</defs>
</svg>

<svg style="display:none">
  <defs>
<symbol id="icon-plus" class="icon icon-plus" viewBox="0 0 93.562 93.562" fill="none" xmlns="http://www.w3.org/2000/svg">
<path xmlns="http://www.w3.org/2000/svg" d="M87.952,41.17l-36.386,0.11V5.61c0-3.108-2.502-5.61-5.61-5.61c-3.107,0-5.61,2.502-5.61,5.61l0.11,35.561H5.61   c-3.108,0-5.61,2.502-5.61,5.61c0,3.107,2.502,5.609,5.61,5.609h34.791v35.562c0,3.106,2.502,5.61,5.61,5.61   c3.108,0,5.61-2.504,5.61-5.61V52.391h36.331c3.108,0,5.61-2.504,5.61-5.61C93.562,43.672,91.032,41.17,87.952,41.17z"  fill="currentColor"/>
	  </symbol>
	</defs>
</svg>

<svg style="display:none">
  <defs>
<symbol  class="icon icon-arrow" id="icon-arrow" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 490.8 490.8" fill="none" aria-hidden="true" focusable="false" role="presentation">
	<path d="M135.685 3.128c-4.237-4.093-10.99-3.975-15.083.262-3.992 4.134-3.992 10.687 0 14.82l227.115 227.136-227.136 227.115c-4.237 4.093-4.354 10.845-.262 15.083 4.093 4.237 10.845 4.354 15.083.262.089-.086.176-.173.262-.262l234.667-234.667c4.164-4.165 4.164-10.917 0-15.083L135.685 3.128z" fill="currentColor"/>
	<path d="M128.133 490.68a10.667 10.667 0 01-7.552-18.219l227.136-227.115L120.581 18.232c-4.171-4.171-4.171-10.933 0-15.104 4.171-4.171 10.933-4.171 15.104 0l234.667 234.667c4.164 4.165 4.164 10.917 0 15.083L135.685 487.544a10.663 10.663 0 01-7.552 3.136z"/>
</symbol>
	</defs>
</svg>

<svg style="display:none">
  <defs>
<symbol id="icon-search" class="icon icon-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192.904 192.904">
  <path d="M190.707 180.101l-47.078-47.077c11.702-14.072 18.752-32.142 18.752-51.831C162.381 36.423 125.959 0 81.191 0 36.422 0 0 36.423 0 81.193c0 44.767 36.422 81.187 81.191 81.187 19.688 0 37.759-7.049 51.831-18.751l47.079 47.078a7.474 7.474 0 005.303 2.197 7.498 7.498 0 005.303-12.803zM15 81.193C15 44.694 44.693 15 81.191 15c36.497 0 66.189 29.694 66.189 66.193 0 36.496-29.692 66.187-66.189 66.187C44.693 147.38 15 117.689 15 81.193z"/>
</symbol>
	</defs>
</svg>
		<script>
	if (f1genzPS) {
	$(document).ready(()=>{
		$.ajax({
			type: 'GET',
			url: '/search?view=template',
			success: function (xhtml){
				const stringobj = xhtml.replace(/^\s+|\s+$/gm, "");
				const OBJTemplate = JSON.parse(stringobj.replace(/(\r\n|\n|\r)/gm, ""));
				
				if($(window).width() > 991){
					const tempmain_menu = OBJTemplate.main_menu.replace(/@####@/g, '"');
					$('#nav-main-menu').html(tempmain_menu);
				}
				
				

			}
		});
	});
		}
</script>




		




				<script type="text/x-custom-template" data-template="ItemDropCart">
	<li class="item productid-${id_item}" data-line="${index}">
		<div class="border_list"><div class="image_drop">
			<a class="product-image pos-relative embed-responsive embed-responsive-1by1" href="${url}" title="${title}">
				<img alt="${title}" src="${image_url}"width="'+ '100' +'"\>
	</a>
	</div>
			<div class="detail-item">
				<div class="product-details">
					<span href="javascript:;" data-id="${id_item}" title="Xóa" class="remove-item-cart fa fa-times"></span>
					<p class="product-name"> <a href="${url}" title="${title}">${title}</a></p></div>
					<span class="variant-title">${variant_title}</span>
				<div class="product-details-bottom"><span class="price">${price}</span>
					<span class="quanlity">x ${quanty}</span>
					<div class="quantity-select qty_drop_cart d-none">
						<input class="variantID" type="hidden" name="variantId" value="${id_item}">
						<button onClick="var result = document.getElementById('qty${id_item}'); var qty${id_item} = result.value; if( !isNaN( qty${id_item} ) &amp;&amp; qty${id_item} &gt; 1 ) result.value--;return false;" class="btn btn_reduced reduced items-count btn-minus" ${buttonQty} type="button">–</button>
						<input type="text" maxlength="3" min="1" readonly class="form-control input-text number-sidebar qty${id_item}" id="qty${id_item}" name="Lines" id="updates_${id_item}" size="4" value="${quanty}">
						<button onClick="var result = document.getElementById('qty${id_item}'); var qty${id_item} = result.value; if( !isNaN( qty${id_item} )) result.value++;return false;" class=" btn btn_increase increase items-count btn-plus" type="button">+</button>
	</div>
	</div>
	</div>
	</div>
	</li>
</script>

<script type="text/x-custom-template" data-template="HeaderCartPc">
	  <div class="cart page_cart hidden-xs hidden-sm row">
		<form action="/cart" method="post" novalidate class="formcartpage col-lg-12 col-md-12 margin-bottom-0">
			<div class="bg-scroll">
				<div class="cart-thead">
					<div style="width: 18%" class="a-center">Ảnh sản phẩm</div>
					<div style="width: 32%" class="a-center">Tên sản phẩm</div>
					<div style="width: 17%" class="a-center">Đơn giá</div>
					<div style="width: 14%" class="a-center">Số lượng</div>
					<div style="width: 14%" class="a-center">Thầnh tiền</div>
					<div style="width: 5%" class="a-center">Xóa</div>
	</div>
				<div class="cart-tbody">
	</div>
	</div>
	</form>
	</div>
</script>
<script type="text/x-custom-template" data-template="pageCartCheckout">
	  <div class="col-lg-7 col-md-7">
		<a href="/" class="form-cart-continue">Tiếp tục mua hàng</a>
	</div>
	  <div class="col-lg-5 col-md-5">
		<div class="section bg_cart shopping-cart-table-total">
			<div class="table-total">
				<table class="table">
					<tr>
						<td coldspan="20" class="total-text">Tổng tiền thanh toán: </td>
						<td class="txt-right totals_price price_end a-right">${price_total}</td>
	</tr>
	</table>
	</div>
	</div>
		<div class="section continued">
			<a href="/checkout" class="btn-checkout-cart button_checkfor_buy">Tiến hành thanh toán</a>
	</div>
	</div>
</script>

<script type="text/x-custom-template" data-template="pageCartItem">
	  <div class="item-cart productid-${id_item}" data-line="${index}">
		<div style="width: 18%" class="image">
			<a class="product-image a-left" title="${title}" href="${url}">
				<img width="75" height="auto" alt="${title}" src="${image_url}">
	</a>
	</div>
		<div style="width: 32%" class="a-center">
			<h3 class="product-name"> <a class="text2line" href="${url}" title="${title}">
			${title}</a> </h3>
			<span class="variant-title">${variant_title}</span>
			<a class="remove-itemx remove-item-cart" title="Xóa" href="javascript:;" data-id="${id_item}">
				<span><i class="fa fa-times"></i></span>
	</a>
	</div>
		<div style="width: 17%" class="a-center">
			<span class="cart-prices">
				<span class="prices">${price}</span> 
	</span>
	</div>
		<div style="width: 14%" class="a-center">
			<div class="input_qty_pr">
				<input class="variantID" type="hidden" name="variantId" value="${id_item}">
				<button onClick="var result = document.getElementById('qtyItem${id_item}'); var qtyItem${id_item} = result.value; if( !isNaN( qtyItem${id_item} ) &amp;&amp; qtyItem${id_item} &gt; 1 ) result.value--;return false;" ${buttonQty} class="reduced_pop items-count btn-minus" type="button">-</button>
				<input type="text" maxlength="3" readonly min="0" class="check_number_here input-text number-sidebar input_pop input_pop qtyItem${id_item}" id="qtyItem${id_item}" name="Lines" id="updates_${id_item}" size="4" value="${quanty}">
				<button onClick="var result = document.getElementById('qtyItem${id_item}'); var qtyItem${id_item} = result.value; if( !isNaN( qtyItem${id_item} )) result.value++;return false;" class="increase_pop items-count btn-plus" type="button">+</button>
	</div>
	</div>
		<div style="width: 14%" class="a-center">
			<span class="cart-price">
				<span class="price">${price_quanty}</span> 
	</span>
	</div>
		<div style="width: 5%" class="a-center">
			<a class="remove-itemx remove-item-cart" title="Xóa" href="javascript:;" data-id="${id_item}">
				<span><i class="fa fa-trash-alt"></i></span>
	</a>
	</div>
	</div>
</script>

<script type="text/x-custom-template" data-template="ItemCartMobile">
	  <div class="item-product item productid-${id_item}" data-line="${index}">
		<div class="text-center">
			<a class="remove-itemx remove-item-cart " title="Xóa" href="javascript:;" data-id="${id_item}">
				<svg  class="icon" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0)">
<path d="M0.620965 12C0.462896 12 0.304826 11.9399 0.184729 11.8189C-0.0563681 11.5778 -0.0563681 11.1869 0.184729 10.9458L10.9497 0.180823C11.1908 -0.0602744 11.5817 -0.0602744 11.8228 0.180823C12.0639 0.421921 12.0639 0.8128 11.8228 1.05405L1.05795 11.8189C0.936954 11.9392 0.778884 12 0.620965 12Z" fill="#8C9196"/>
<path d="M11.3867 12C11.2287 12 11.0707 11.9399 10.9505 11.8189L0.184729 1.05405C-0.0563681 0.8128 -0.0563681 0.421921 0.184729 0.180823C0.425827 -0.0602744 0.816706 -0.0602744 1.05795 0.180823L11.8228 10.9458C12.0639 11.1869 12.0639 11.5778 11.8228 11.8189C11.7018 11.9392 11.5439 12 11.3867 12Z" fill="#8C9196"/>
</g>
<defs>
<clipPath id="clip0">
<rect width="12" height="12" fill="white"/>
</clipPath>
</defs>
</svg>
	</a>
	</div>
		<div class="item-product-cart-mobile">
				<a class="product-images1 pos-relative embed-responsive embed-responsive-1by1" href="${url}" title="${title}">
					<img class="img-fluid" src="${image_url}" alt="${title}"/>
																<div class="label_product product_gift_label hidden" data-id="${pd_id}">
							<img src="//theme.hstatic.net/200000551679/1001345525/14/ega-product-gift.png?v=1469" alt="product gift">
	</div>
						</a>
	</div>
		<div class="product-cart-infor">
		<div class="title-product-cart-mobile">
			<h3 class="product-name"> <a class="text2line" href="${url}" title="${title}">
			${title}</a>  </h3>
			<span class="variant-title">${variant_title}</span>
	</div>

		<div class="cart-price">
			<span class="product-price price">${price_quanty}</span>
	</div>
		<div class="select-item-qty-mobile">
		
			<div class="txt_center">

			<input class="variantID" type="hidden" name="id" value="${id_item}" line="${line_index}">
					
				<button onClick="var result = document.getElementById('qtyMobile${id_item}'); var qtyMobile${id_item} = result.value; if( !isNaN( qtyMobile${id_item} ) &amp;&amp; qtyMobile${id_item} &gt; 1 ) result.value--;return false;" class="reduced items-count btn-minus btn" type="button"><svg class="icon">
	<use xlink:href="#icon-minus" />
</svg></button>

				<input type="text" maxlength="3" min="1" class="form-control input-text number-sidebar qtyMobile${id_item}" id="qtyMobile${id_item}" name="updates[]" id="updates_${id_item}" size="4" value="${quanty}">

				<button onClick="var result = document.getElementById('qtyMobile${id_item}'); var qtyMobile${id_item} = result.value; if( !isNaN( qtyMobile${id_item} )) result.value++;return false;" class="increase items-count btn-plus btn" type="button"><svg class="icon">
	<use xlink:href="#icon-plus" />
</svg></button>
	
	</div>
	</div>
	</div>
	</div>
</script>
<script type="text/x-custom-template" data-template="pageCartCheckoutMobile">
	  <div class="header-cart-price">
	  	<div class="timedeli-modal">
		<div class="timedeli-modal-content">
		<button type="button" class="close window-close d-sm-none" 
        aria-label="Close" style="z-index: 9;"><span aria-hidden="true">×</span></button>
	    <div class="timedeli d-sm-block"></div>
		<div class="timedeli-cta">
			<button class="btn btn-block timedeli-btn  d-sm-none" 
			        type="button">
				<span>Xong</span>
	</button>		
	</div>
	</div>

			 <div class="timedeli-overaly">
	</div>
	</div>
	    





<div class="r-bill">
	<div class="checkbox">
		<input type="hidden" name="attributes[invoice]" id="re-checkbox-bill" value='không'>
		<input type="checkbox" id="checkbox-bill" value="có"  class="regular-checkbox" />
		<label for="checkbox-bill" class="box"></label>
		<label for="checkbox-bill" class="title">Xuất hóa đơn công ty</label>
	</div>
	<div class="bill-field">
		<div class="form-group">
			<label>Tên công ty</label>
			<input type="text" class="form-control val-f" 
				   name="attributes[company_name]" 
				   value=""
				   placeholder="Tên công ty" >
		</div>	
		<div class="form-group">
			<label>Mã số thuế</label>
			<input type="number" pattern=".{10,}" onkeydown="return FilterInput(event)" 
				   onpaste="handlePaste(event)" 
				   class="form-control val-f val-n" 
				   name="attributes[tax_code]" 
				   value="" 
				   placeholder="Mã số thuế">
		</div>
		<div class="form-group">
			<label>Địa chỉ công ty</label>
			<textarea type="text" class="form-control val-f" 
					  name="attributes[company_address]" 
					  value="" 
					  placeholder="Nhập địa chỉ công ty (bao gồm Phường/Xã, Quận/Huyện, Tỉnh/Thành phố nếu có)"></textarea>
		</div>
		<div class="form-group">
			<label>Email nhận hoá đơn</label>
			<input type="email" class="form-control val-f val-email" 
				   name="attributes[invoice_email]" 
				   value="" 
				   placeholder="Email nhận hoá đơn">
		</div>
	</div>
</div>


		<div class="title-cart d-none d-sm-flex ">
			<h3 class="text-xs-left">TỔNG CỘNG</h3>
			<span class="text-xs-right  totals_price_mobile">${price_total}</span>
			<i class="text-xs-right price_vat ">(Đã bao gồm VAT nếu có)</i>	</div>
		
		

		<div class="checkout d-none d-sm-block">
			<button class="btn btn-block btn-proceed-checkout-mobile" title="Tiến hành thanh toán" name="checkout"
			        type="button" onclick='goToCheckout(event)'>
				<span>Thanh Toán</span>
	</button>		
				<a href="" class="btn btn-block btn-proceed-checkout-mobile ruticheckout">Thanh toán</a>
	</div>
					</div>

</script>
<script type="text/x-custom-template" data-template="templateStickyCheckout">
  <div class="cart-sticky-cta">
	  

	  	
		<div class="cart-cta">

				<div>
				<button class="btn btn-block btn-proceed-checkout-mobile" title="Tiến hành thanh toán" name="checkout"
			        type="button" onclick="goToCheckout(event)">
				<span>Thanh Toán</span> <span class="text-xs-right  totals_price_mobile">${price_total}</span>
	</button>	
	<a href="" class="btn btn-block btn-proceed-checkout-mobile ruticheckout"><span>Thanh Toán </span> <span class="text-xs-right  totals_price_mobile">${price_total}</span></a>
					<i class="text-xs-right price_vat ">(Đã bao gồm VAT nếu có)</i>	</div>
	</div>
	</div>
</script>

<script type="text/x-custom-template" data-template="TemplateItemPopupCart">
	<div class="item-popup productid-${id_item}">
		<div style="width: 13%;" class="height image_ text-left">
			<div class="item-image">
				<a class="product-image" href="${url}" title="${title}">
					<img alt="${title}" src="${image_url}"width="'+ '90' +'"\>
	</a>
	</div>
	</div>
		<div style="width:40%;" class="height text-left fix_info">
			<div class="item-info">
				<p class="item-name">
					<a class="text2line textlinefix" href="${url}" title="${title}">${title}</a>
	</p>
				<span class="variant-title-popup">${variant_title}</span>
				<a href="javascript:;" class="remove-item-cart" title="Xóa" data-id="${id_item}">
					<i class="fa fa-times"></i>&nbsp;&nbsp;Bỏ sản phẩm
	</a>
				<p class="addpass" style="color:#fff;margin:0px;">${id_item}</p>
	</div>
	</div>
		<div style="width: 15%;" class="height text-center">
			<div class="item-price">
				<span class="price">${price}</span>
	</div>
	</div>
		<div style="width: 15%;" class="height text-center">
			<div class="qty_h check_">
				<input class="variantID" type="hidden" name="variantId" value="${id_item}">
				<button onClick="var result = document.getElementById('qtyItemP${id_item}'); var qtyItemP${id_item} = result.value; if( !isNaN( qtyItemP${id_item} ) &amp;&amp; qtyItemP${id_item} &gt; 1 ) result.value--;return false;" ${buttonQty} class="num1 reduced items-count btn-minus" type="button">-</button>
				<input type="text" maxlength="3" min="0" readonly class="input-text number-sidebar qtyItemP${id_item}" id="qtyItemP${id_item}" name="updates[]" id="updates_${id_item}" size="4" value="${quanty}">
				<button onClick="var result = document.getElementById('qtyItemP${id_item}'); var qtyItemP${id_item} = result.value; if( !isNaN( qtyItemP${id_item} )) result.value++;return false;" class="num2 increase items-count btn-plus" type="button">+</button>
	</div>
	</div>
		<div style="width: 17%;" class="height text-center">
			<span class="cart-price">
				<span class="price">${price_quanty}</span>
	</span>
	</div>
	</div>
</script>

				<div id="popup-cart" class="popcart">
	<div id="popup-cart-desktop" class="clearfix">
		<div class="title-popup-cart">
		</div>          
		<div class="wrap_popup">
			<div class="title-quantity-popup" >
				<span class="cart_status" onclick="window.location.href='/cart';">
					Giỏ hàng của bạn có <span class="cart-popup-count"></span> sản phẩm
				</span>
			</div>
			<div class="content-popup-cart">
				<!-- <div class="thead-popup">
					<div style="width: 53%;" class="text-left">Sản phẩm</div>
					<div style="width: 15%;" class="text-center">Đơn giá</div>
					<div style="width: 15%;" class="text-center">Số lượng</div>
					<div style="width: 17%;" class="text-center">Thành tiền</div>
				</div> -->
				<div class="tbody-popup scrollbar-dynamic">
				</div>
				<div class="tfoot-popup">
					<div class="tfoot-popup-1 clearfix">
						<div class="popup-ship">
						</div>
						<span class="total-p popup-total">Tổng tiền thanh toán: <span class="total-price"></span></span>
					</div>
					<div class="tfoot-popup-2 clearfix">
						<a class="button btn-continue close-pop" title="Tiếp tục mua hàng" href="javascript:;" onclick="$('#popup-cart').modal('hide');"><span><span>Tiếp tục mua hàng</span></span></a>
						<a class="button checkout_ btn-proceed-checkout" title="Thực hiện thanh toán" href="/checkout"><span>Thực hiện thanh toán</span></a>
					</div>
				</div>
			</div>
			<a title="Close" class="close-modal quickview-close close-pop" href="javascript:;" onclick="$('#popup-cart').modal('hide');"><i class="fa fa-close"></i></a>
		</div>
	</div>

</div>
		<script>
	/* start callback km*/
	

	let get_cart = link_checkout =>{
		$.ajax({
			type: 'GET',
			url: '/cart.js',
			async: false,
			cache: false,
			dataType: 'json',
			success: function (cart){
        //debugger
				let index = cart.items.findIndex(variant => variant.variant_id == campaign_dc.product);
				if(campaign_dc.employ == true){
					
					if(index > -1 && cart.total_price >= campaign_dc.price_setup){
						template != 'cart' ? updateCartModal(link_checkout) : '';
					}
					else if(index > -1 && cart.total_price < campaign_dc.price_setup){
						remove_camp(index+1,link_checkout);
						window.location.reload();
					}
					else if(index == -1 && cart.total_price >= campaign_dc.price_setup){
						//add_item_campaign(campaign_dc.product,link_checkout)
						getProductGift(campaign_dc.productHandle,link_checkout);
					}else{
						template != 'cart' ? updateCartModal(link_checkout) : '';
					}
				}
				else{
					
					template != 'cart' ? updateCartModal(link_checkout) : '';
					index > -1 ? remove_camp(index+1,link_checkout) : '';
					
				}

			}
		}).done(() =>{
			setTimeout(() =>{
				//getCartModal();
				jQuery.getJSON('/cart.js', function(cart, textStatus) {
					if(cart.items.length > 0){
						//debug 1
						addToCartSuccess(cart);
					}
				})
			},300)
		});
	}
	let remove_camp = (line,link_checkout) =>{
		var params = {
			type: 'POST',
			url: '/cart/change.js',
			data: 'quantity=0&line=' + line,
			dataType: 'json',
			success: function(cart) {
				$(`.item-product[data-line="${line}"]`).remove();
				if(template != 'cart'){
					//getCartModal()
					addToCartSuccess(cart);
				}
			},
			error: (XMLHttpRequest, textStatus) => {

			}
		};
		jQuery.ajax(params);
	}
	let add_item_campaign = (id,link_checkout) =>{
		$.ajax({
			type: 'POST',
			url: '/cart/add.js',
			async: false,
			data: 'quantity=1&id=' + id,
			dataType: 'json',
			success: function(line_item) {
				if(template == 'cart'){
					location.reload();
				}
				else{
					$('#modalProductGift').css('display','none');
					$('#modalProductGift').removeClass("active");
					setTimeout(function(){
						$('.product-gift-content').removeClass('show');
					}, 100);
					addToCartSuccess(line_item);
					updateCartModal(link_checkout);
				}
			},
			error: function(XMLHttpRequest, textStatus) {
				alert('Sản phẩm bạn vừa mua đã vượt quá tồn kho');
			}
		})
	}
	


	function updateCartModal(link_checkout){

	}
	function getProductGift(handle,link_checkout){
		$.ajax({
			type: 'GET',
			url: '/products/'+handle+'?view=gift',
			async : false,
			success: function(data) {
				//do html vao day
				$('#modalProductGift').html(data);
				$('#modalProductGift').css('display','block');
				$('#modalProductGift').addClass("active");
				setTimeout(function(){
					$('.product-gift-content').addClass('show');
				}, 100);
				$('.btn-buygift').click(function(){
					var vid = $(this).attr('data-vid');
					add_item_campaign(vid,link_checkout)
				});
			}
		})
	}

	/* end callback km*/

	var GLOBAL = {
		common : {
			init: function(){
				$(document).on('click', '.add_to_cart',addToCart )
				$(document).on('click', '.buynow',buynow )
			}
		},
		templateIndex : {
			init: function(){
			}
		},
		templateProduct : {
			init: function(){
			}
		},
		templateCart : {
			init: function(){
			}
		}
	}
	var UTIL = {
		fire : function(func,funcname, args){
			var namespace = GLOBAL;
			funcname = (funcname === undefined) ? 'init' : funcname;
			if (func !== '' && namespace[func] && typeof namespace[func][funcname] == 'function'){
				namespace[func][funcname](args);
			}
		},
		loadEvents : function(){
			var bodyId = document.body.id;
			UTIL.fire('common');
			$.each(document.body.className.split(/\s+/),function(i,classnm){
				UTIL.fire(classnm);
				UTIL.fire(classnm,bodyId);
			});
		}
	};
	$(document).ready(UTIL.loadEvents);
	Number.prototype.formatMoney = function(c, d, t){
		var n = this, 
				c = isNaN(c = Math.abs(c)) ? 2 : c, 
				d = d == undefined ? "." : d, 
				t = t == undefined ? "." : t, 
				s = n < 0 ? "-" : "", 
				i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", 
				j = (j = i.length) > 3 ? j % 3 : 0;
		return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
	};
	function addToCart(e,link_checkout){
		if (typeof e !== 'undefined') e.preventDefault();
		var $this = $(this);
		var form = $this.parents('form');	

		var variantId = form.find("[name=id]").val();
		var qtt = form.find("[name=quantity]").val();
		//debugger
		var boolCombo = false;
		var boolBuyXgetY = false;
		if($("#add-to-cart-form").length > 0){
			if($("#add-to-cart-form").find(".add_to_cart").hasClass("product-combo")){
				boolCombo = true;
			}
			if($("#add-to-cart-form").find(".add_to_cart").hasClass("product-buyxgety")){
				boolBuyXgetY = true;
			}
		}

		if(boolCombo){
			$('#popupComboModal').modal();
		} else if(boolBuyXgetY){
			buyXgetY.addCartBuyXGetY_detail(true,variantId,qtt,(jqXHR, textStatus, errorThrown) => {
				addToCartSuccess(jqXHR, textStatus, errorThrown);
				get_cart(link_checkout);		
			})
		}else { 
			$.ajax({
				type: 'POST',
				url: '/cart/add.js',
				async: false,
				data: form.serialize(),
				dataType: 'json',
				error: addToCartFail,
				beforeSend: function() {  
				},
				success:function(cart){
					get_cart(link_checkout);
					addToCartSuccess(cart);
				},
				cache: false
			});
		}
	}
	function buynow(e){
		if (typeof e !== 'undefined') e.preventDefault();
		var $this = $(this);
		var form = $this.parents('form');	
		var variantId = form.find("[name=id]").val();
		var qtt = form.find("[name=quantity]").val();
		var form = $this.parents('form');		
		const callback = (cart) => {
			location.href = '/checkout';
		}
		var boolCombo = false;
		var boolBuyXgetY = false;
		if($("#add-to-cart-form").length > 0){
			if($("#add-to-cart-form").find(".add_to_cart").hasClass("product-combo")){
				boolCombo = true;
			}
			if($("#add-to-cart-form").find(".add_to_cart").hasClass("product-buyxgety")){
				boolBuyXgetY = true;
			}
		}

		if(boolCombo){
			$('#popupComboModal').modal();
		} else if(boolBuyXgetY){
			buyXgetY.addCartBuyXGetY_detail(true,variantId,qtt,(jqXHR, textStatus, errorThrown) => {
				addToCartSuccess(jqXHR, textStatus, errorThrown)
				location.href = '/checkout';
			})
		}else { 
			$.ajax({
				type: 'POST',
				url: '/cart/add.js',
				async: false,
				data: form.serialize(),
				dataType: 'json',
				error: addToCartFail,
				beforeSend: function() {  
				},
				success: (cart) => {
					//addToCartSuccess(jqXHR, textStatus, errorThrown,callback)
					/*
					get_cart();
					addToCartSuccess(cart);
					*/
					
					location.href = '/checkout';
				},
				cache: false
			});
		}
	}
	function qty(){	
		var dqty = $('#qtym').val();	
		if (dqty == undefined){
			return 1;
		}
		return dqty;
	}

	function checkCartLimit(e, totalPrice) {
		e.preventDefault();
		
		 location.href = '/checkout';
			
			}
			function addToCartSuccess (jqXHR, textStatus, errorThrown,callback){
				
				console.log(jqXHR['url'])
				$.ajax({
					type: 'GET',
					url: '/cart.js',
					async: false,
					cache: false,
					dataType: 'json',
					success: function (cart){
						awe.hidePopup('.loading');
						var url_product = jqXHR['url'];
						var class_id = jqXHR['product_id'];
						var name = jqXHR['name'];
						var textDisplay = ('<i style="margin-right:5px; color:red; font-size:13px;" class="fa fa-check" aria-hidden="true"></i>Sản phẩm vừa thêm vào giỏ hàng');
						var id = jqXHR['variant_id'];
						var dataList = $(".item-name a").map(function() {
							var plus = $(this).text();
							return plus;
						}).get();
						$('.title-popup-cart .cart-popup-name').html('<a href="'+ url_product +'" title="'+name+'">'+ name + '</a> ');
						var nameid = dataList,
								found = $.inArray(name, nameid);
						var textfind = found;

						var src = '';
						if(!jqXHR['image'] || (Haravan.resizeImage(jqXHR['image'], 'small') == null || Haravan.resizeImage(jqXHR['image'], 'small') =="null" || Haravan.resizeImage(jqXHR['image'], 'small')) =='') {
							src= "//theme.hstatic.net/200000551679/1001345525/14/noimage.gif?v=1469"
						}
						else
						{
							src=  Haravan.resizeImage(jqXHR['image'], 'small')
						}
						$(".item-info > p:contains("+id+")").html('<span class="add_sus" style="color:#898989;"><i style="margin-right:5px; color:#3cb878; font-size:14px;" class="fa fa-check" aria-hidden="true"></i>Sản phẩm vừa thêm</span>');

						var va_title = jqXHR['variant_options'].filter(opt =>  opt != 'Default Title').join(', ');
						console.log('jqXHR',jqXHR['variant_options']);
						
						var windowW = $(window).width();
						$('#popup-cart').addClass('opencart');
						$('body').addClass('opacitycart');
						$('#popup-cart').addClass('opencart');
						$('body').addClass('opacitycart');
						$('#popupCartModal').html('');
						const limit = Number(0)
				const  cart_action = cart.total_price >= limit ? `
<a href="/checkout" class="btn btn-main btn-full">Thanh toán</a>
<a  href="/cart" class="btn btn-main checkout_button btn-full">Xem giỏ hàng</a>
`: `
<button type="button" class="btn btn-main" data-dismiss="modal" data-backdrop="false"
aria-label="Close" >Mua thêm</button>
<a  href="/cart" class="btn btn-main  checkout_button btn-full">Xem giỏ hàng</a>
`
				let limit_message  = `Đơn hàng của bạn chưa đạt giá trị tối thiểu 1.000.000đ. 
Vui lòng chọn mua thêm sản phẩm`
				limit_message = limit_message ? `<span class="mr-2"><i class="fa fa-info-circle" aria-hidden="true"></i></span> ${limit_message}`  : ''
				var $popupMobile = `<div class="modal-dialog align-vertical">
    <div class="modal-content "><button type="button" class="close" data-dismiss="modal" data-backdrop="false"
        aria-label="Close" style="z-index: 9;"><span aria-hidden="true">×</span></button>
      <div class="row row-noGutter">
        <div class="modal-left col-sm-12 col-lg-12 col-md-12">
          <h3 class="modal-title"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.00006 15.3803C12.0761 15.3803 15.3804 12.076 15.3804 7.99995C15.3804 3.92391 12.0761 0.619629 8.00006 0.619629C3.92403 0.619629 0.619751 3.92391 0.619751 7.99995C0.619751 12.076 3.92403 15.3803 8.00006 15.3803Z" fill="#2EB346"/>
            <path d="M8 16C3.58916 16 0 12.4115 0 8C0 3.58916 3.58916 0 8 0C12.4115 0 16 3.58916 16 8C16 12.4115 12.4115 16 8 16ZM8 1.23934C4.27203 1.23934 1.23934 4.27203 1.23934 8C1.23934 11.728 4.27203 14.7607 8 14.7607C11.728 14.7607 14.7607 11.7273 14.7607 8C14.7607 4.27203 11.728 1.23934 8 1.23934Z" fill="#2EB346"/>
            <path d="M7.03336 10.9434C6.8673 10.9434 6.70865 10.8771 6.59152 10.7582L4.30493 8.43438C4.06511 8.19023 4.06821 7.7986 4.31236 7.55816C4.55652 7.31898 4.94877 7.32145 5.18858 7.5656L7.0154 9.42213L10.7948 5.25979C11.0259 5.00635 11.4176 4.98838 11.6698 5.21766C11.9232 5.44757 11.9418 5.8392 11.7119 6.09326L7.49193 10.7408C7.3773 10.8672 7.21618 10.9403 7.04577 10.944C7.04143 10.9434 7.03771 10.9434 7.03336 10.9434Z" fill="white"/>
            </svg>
            <span>Thêm vào giỏ hàng thành công</span></h3>
          <div class="modal-body">
            <div class="media">
              <div class="media-left thumb_img">
                <div class="thumb-1x1"><img
                    src="${src}"
                    alt="${jqXHR['title']}"></div>
              </div>
              <div class="media-body body_content">
                <div class="product-title">${jqXHR['title']}</div>
                <div class="variant_title font-weight-light"><span>${va_title}</span></div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-right margin-top-10 col-sm-12 col-lg-12 col-md-12">
          <div class="title right_title d-flex justify-content-between" ><a href="/cart"> Giỏ hàng hiện có </a>
        <div class="text-right">
            <span class="price">${Haravan.formatMoney(cart.total_price, '{{amount}}₫')}</span>
            <div class="count font-weight-light">
				(<span
            class="cart-popup-count">4</span>) sản phẩm 
			</div>
        </div>
			
      
          </div>
			
			${cart.total_price < limit ? `  <div class="cart-message">${limit_message}</div>`:'' }
			  
			  <div class="cart-action">
				            ${cart_action}

			  </div>
        </div>
      </div>
    </div>
  </div>`;
				$('#popupCartModal').html($popupMobile);

				if(typeof callback == 'function' &&  cart.total_price >= limit){
					return	callback(cart)
				}
				$('#popupCartModal').modal(); 
				Haravan.updateCartFromForm(cart, '.top-cart-content .mini-products-list');
				Haravan.updateCartPopupForm(cart, '#popup-cart-desktop .tbody-popup');
				
				 }
				});
			}
			function addToCartFail(jqXHR, textStatus, errorThrown){
				var response = $.parseJSON(jqXHR.responseText);
				var $info = '<div class="error">'+ response.description +'</div>';
			}
			function getDelivery(){
				if(!$('.ega-delivery').length && window.egaDeliveryValid){
					var head = document.getElementsByTagName('head').item(0);
					var script = document.createElement('script');
					script.setAttribute('src', 'https://mixcdn.egany.com/themes/delivery-builtin/index.min.js');
					head.appendChild(script);
				}

			}
			/*
			$(document).on('click', ".remove-item-cart", function () {
		var variantId = $(this).attr('data-id');
		removeItemCart(variantId);
	});*/
			
			$(document).on('click', ".remove-item-cart", function () {
				debugger 
				let line = $(this).parents('.item-product').attr('data-line');
				$(`.item-product[data-line="${line}"]`).remove();
				var variantId = $(this).attr('data-id');
				removeItemCart(variantId);				
			});
			/*
			$(document).on('click', ".items-count", function () {
				$(this).parent().children('.items-count').prop('disabled', true);
				var thisBtn = $(this);
				var variantId = $(this).parent().find('.variantID').val();
				var qty =  $(this).parent().children('.number-sidebar').val();
				updateQuantity(qty, variantId);
			});
			$(document).on('change', ".number-sidebar", function () {
				var variantId = $(this).parent().children('.variantID').val();
				var qty =  $(this).val();
				updateQuantity(qty, variantId);
			});
			function updateQuantity (qty, variantId){
				var variantIdUpdate = variantId;
				$.ajax({
					type: "POST",
					url: "/cart/change.js",
					data: {"quantity": qty, "id": variantId},
					dataType: "json",
					success: function (cart, variantId) {
						Haravan.onCartUpdateClick(cart, variantIdUpdate);
						cart_min();
						get_cart();
						
					},
					error: function (qty, variantId) {
						Haravan.onError(qty, variantId)
					}
				})
			}
			function removeItemCart (variantId){
				var variantIdRemove = variantId;
				var changeData = {"quantity": 0, "id": variantId}

								
				 $.ajax({
					 type: "POST",
					 url: "/cart/change.js",
					 data: changeData,
					 dataType: "json",
					 success: function (cart, variantId) {
						 Haravan.onCartRemoveClick(cart, variantIdRemove);
						 $('.productid-'+variantIdRemove).remove();
						 if($('.tbody-popup>div').length == '0' ){
							 $('#popup-cart').removeClass('opencart');
							 $('body').removeClass('opacitycart');
						 }
						 if($('.list-item-cart>li').length == '0' ){
							 $('.mini-products-list').html('<div class="no-item"><p>Không có sản phẩm nào.</p></div>');
						 }
						 if($('.cart-mobile .item-product').length == '0' ){
							 $('.page_cart').empty();
							 $('.header-cart-content').empty();
							 $('.cart-mobile .header-cart').hide()
							 $('.title_cart_pc').html('<p class="hidden-xs-down">Không có sản phẩm nào. Quay lại <a href="/" style="color:;">cửa hàng</a> để tiếp tục mua sắm.</p>');
							 $('.cart-empty').show()
							 $('.cart-sticky-cta').remove()
						 }
						 cart_min();
						 get_cart();
						 
					 },
					 error: function (variantId, r) {
						 Haravan.onError(variantId, r)
					 }
				 })
				 }
			
			*/
			$(document).on('click', ".items-count", function () {
				$(this).parent().children('.items-count').prop('disabled', true);
				var thisBtn = $(this);
				var variantId = $(this).parent().find('.variantID').val();
				var qty =  $(this).parent().children('.number-sidebar').val();
				 var lineIndex = $(this).parent().find('.variantID').attr("line");
					updateQuantity(qty, variantId, lineIndex);
			
			});
			$(document).on('change', ".number-sidebar", function () {
				var variantId = $(this).parent().children('.variantID').val();
				var lineIndex = $(this).parent().find('.variantID').attr("line");
				var qty =  $(this).val();
				updateQuantity(qty, variantId, lineIndex);
			});
		
					function updateQuantity (qty, variantId, lineIndex){
					var variantIdUpdate = variantId;
					var dataObj = {"quantity": qty, "id": variantId};
					if(lineIndex != undefined){
						dataObj = {"quantity": qty, "line": lineIndex}
					}
					$.ajax({
						type: "POST",
						url: "/cart/change.js",
						data: dataObj,
						dataType: "json",
						success: function (cart, variantId) {
							Haravan.onCartUpdateClick(cart, variantIdUpdate);
							cart_min();
							get_cart();
							
							 },
								 error: function (qty, variantId) {
									 Haravan.onError(qty, variantId)
								 }
							})
						}
			function removeItemCart (variantId){
				var variantIdRemove = variantId;
				var changeData = {"quantity": 0, "id": variantId}

								
				 $.ajax({
					 type: "POST",
					 url: "/cart/change.js",
					 data: changeData,
					 dataType: "json",
					 success: function (cart, variantId) {
						 Haravan.onCartRemoveClick(cart, variantIdRemove);
						 $('.productid-'+variantIdRemove).remove();
						 if($('.tbody-popup>div').length == '0' ){
							 $('#popup-cart').removeClass('opencart');
							 $('body').removeClass('opacitycart');
						 }
						 if($('.list-item-cart>li').length == '0' ){
							 $('.mini-products-list').html('<div class="no-item"><p>Không có sản phẩm nào.</p></div>');
						 }
						 if($('.cart-mobile .item-product').length == '0' ){
							 $('.page_cart').empty();
							 $('.header-cart-content').empty();
							 $('.cart-mobile .header-cart').hide()
							 $('.title_cart_pc').html('<p class="hidden-xs-down">Không có sản phẩm nào. Quay lại <a href="/" style="color:;">cửa hàng</a> để tiếp tục mua sắm.</p>');
							 $('.cart-empty').show()
							 $('.cart-sticky-cta').remove()
						 }
						 cart_min();
						 get_cart();
						 
					 },
					 error: function (variantId, r) {
						 Haravan.onError(variantId, r)
					 }
				 })
				 }
			
			
				 function render(props) {
					 return function(tok, i) {
						 return (i % 2) ? props[tok] : tok;
					 };
				 }
				 Haravan.updateCartFromForm = function(cart, cart_summary_id, cart_count_id) {
					 if ((typeof cart_summary_id) === 'string') {
						 var cart_summary = jQuery(cart_summary_id);
						 if (cart_summary.length) {
							 // Start from scratch.
							 cart_summary.empty();
							 // Pull it all out.        
							 jQuery.each(cart, function(key, value) {
								 if (key === 'items') {
									 var table = jQuery(cart_summary_id);           
									 if (value.length) {   
										 jQuery('<ul class="list-item-cart"></ul>').appendTo(table);
										 jQuery.each(value, function(i, item) {	
											 var buttonQty = "";
											 if(item.quantity == '1'){
												 buttonQty = 'disabled';
											 }else{
												 buttonQty = '';
											 }
											 var link_img0 = Haravan.resizeImage(item.image, 'compact');
											 if(link_img0=="null" || link_img0 =='' || link_img0 ==null){
												 link_img0 = "//theme.hstatic.net/200000551679/1001345525/14/noimage.gif?v=1469";
											 }
											 if(item.variant_title == 'Default Title'){
												 var ItemDropCart = [{
													 index: i+1,
													 url: item.url,
													 image_url: link_img0,
													 price: Haravan.formatMoney(item.price, '{{amount}}₫'),
													 title: item.title,
													 buttonQty: buttonQty,
													 quanty: item.quantity,
													 id_item: item.variant_id,
													 variant_title: ''
												 }]
												 }else {
													 var ItemDropCart = [{
														 index: i+1,
														 url: item.url,
														 image_url: link_img0,
														 price: Haravan.formatMoney(item.price, '{{amount}}₫'),
														 title: item.title,
														 buttonQty: buttonQty,
														 quanty: item.quantity,
														 id_item: item.variant_id,
														 variant_title: item.variant_title,
													 }];
												 }
											 $(function() {
												 var TemplateItemDropCart = $('script[data-template="ItemDropCart"]').text().split(/\$\{(.+?)\}/g);
												 $('.list-item-cart').append(ItemDropCart.map(function(item) {
													 return TemplateItemDropCart.map(render(item)).join('');
												 }));
											 });
										 }); 
										 jQuery('<div class="pd"><div class="top-subtotal">Tổng tiền tạm tính: <span class="price price_big">' + Haravan.formatMoney(cart.total_price, "{{amount}}₫") + '</span></div></div>').appendTo(table);
										 jQuery('<div class="pd right_ct"><a href="/cart" class="btn btn-white"><span>Tiến hành thanh toán</span></a></div>').appendTo(table);
									 }
									 else {
										 jQuery('<div class="no-item"><p>Không có sản phẩm nào.</p></div>').appendTo(table);

									 }
								 }
							 });
						 }
					 }
					 updateCartDesc(cart);
					 var numInput = document.querySelector('#cart-sidebar input.input-text');
					 if (numInput != null){
						 // Listen for input event on numInput.
						 numInput.addEventListener('input', function(){
							 // Let's match only digits.
							 var num = this.value.match(/^\d+$/);
							 if (num == 0) {
								 // If we have no match, value will be empty.
								 this.value = 1;
							 }
							 if (num === null) {
								 // If we have no match, value will be empty.
								 this.value = "";
							 }
						 }, false)
					 }
				 }

				 Haravan.updateCartPageForm = function(cart, cart_summary_id, cart_count_id) {
					 if ((typeof cart_summary_id) === 'string') {
						 var cart_summary = jQuery(cart_summary_id);
						 if (cart_summary.length) {
							 // Start from scratch.
							 cart_summary.empty();
							 // Pull it all out.        
							 jQuery.each(cart, function(key, value) {
								 if (key === 'items') {
									 var table = jQuery(cart_summary_id);           
									 if (value.length) {  

										 var HeaderCartPc = $('script[data-template="HeaderCartPc"]').text().split(/\$\{(.+?)\}/g);
										 var pageCartCheckout = $('script[data-template="pageCartCheckout"]').text().split(/\$\{(.+?)\}/g);

										 $(table).append((function() {
											 return HeaderCartPc.map(render()).join('');
										 }));

										 jQuery.each(value, function(i, item) {
											 var buttonQty = "";
											 if(item.quantity == '1'){
												 buttonQty = 'disabled';
											 }else{
												 buttonQty = '';
											 }
											 var link_img1 = Haravan.resizeImage(item.image, 'compact');
											 if(link_img1=="null" || link_img1 =='' || link_img1 ==null){
												 link_img1 = "//theme.hstatic.net/200000551679/1001345525/14/noimage.gif?v=1469";
											 }


											 if(item.variant_title == 'Default Title'){
												 var ItemCartPage = [{
													 index: i+1,
													 url: item.url,
													 image_url: link_img1,
													 price: Haravan.formatMoney(item.price, '{{amount}}₫'),
													 title: item.title,
													 buttonQty: buttonQty,
													 quanty: item.quantity,
													 variant_title: item.variant_title,
													 price_quanty: Haravan.formatMoney(item.price * item.quantity, "{{amount}}₫"),
													 id_item: item.variant_id,
													 variant_title: ''
												 }]
												 }else {
													 var ItemCartPage = [{
														 index: i+1,
														 url: item.url,
														 image_url: link_img1,
														 price: Haravan.formatMoney(item.price, '{{amount}}₫'),
														 title: item.title,
														 buttonQty: buttonQty,
														 quanty: item.quantity,
														 variant_title: item.variant_title,
														 price_quanty: Haravan.formatMoney(item.price * item.quantity, "{{amount}}₫"),
														 id_item: item.variant_id
													 }]
													 }

											 $(function() {
												 var pageCartItem = $('script[data-template="pageCartItem"]').text().split(/\$\{(.+?)\}/g);
												 $(table.find('.cart-tbody')).append(ItemCartPage.map(function(item) {
													 return pageCartItem.map(render(item)).join('');

												 }));
											 });

										 }); 

										 var PriceTotalCheckout = [{
											 price_total: Haravan.formatMoney(cart.total_price, "{{amount}}₫")
										 }];				
										 $(table.children('.cart')).append(PriceTotalCheckout.map(function(item) {
											 return pageCartCheckout.map(render(item)).join('');
										 }));
									 }else {
										 jQuery('<p class="hidden-xs-down ">Không có sản phẩm nào. Quay lại <a href="/collections/all" style="color:;">cửa hàng</a> để tiếp tục mua sắm.</p>').appendTo(table);
										 jQuery('.cart_desktop_page').css('min-height', 'auto');
									 }
								 }
							 });
						 }
					 }
					 updateCartDesc(cart);
					 
					 jQuery('#wait').hide();

				 }
				 Haravan.updateCartPopupForm = function(cart, cart_summary_id, cart_count_id) {

					 if ((typeof cart_summary_id) === 'string') {
						 var cart_summary = jQuery(cart_summary_id);
						 if (cart_summary.length) {
							 // Start from scratch.
							 cart_summary.empty();
							 // Pull it all out.        
							 jQuery.each(cart, function(key, value) {
								 if (key === 'items') {
									 var table = jQuery(cart_summary_id);           
									 if (value.length) { 
										 jQuery.each(value, function(i, item) {
											 var src = item.image;
											 if(src == null){
												 src = "//theme.hstatic.net/200000551679/1001345525/14/noimage.gif?v=1469";
											 }
											 var buttonQty = "";
											 if(item.quantity == '1'){
												 buttonQty = 'disabled';
											 }else{
												 buttonQty = '';
											 }

											 if(item.variant_title == 'Default Title'){				  
												 var ItemPopupCart = [{
													 index: i+1,
													 url: item.url,
													 image_url: src,
													 price: Haravan.formatMoney(item.price, '{{amount}}₫'),
													 title: item.title,
													 quanty: item.quantity,
													 variant_title: '',
													 price_quanty: Haravan.formatMoney(item.price * item.quantity, "{{amount}}₫"),
													 id_item: item.variant_id
												 }];
											 }else {
												 var ItemPopupCart = [{
													 index: i+1,
													 url: item.url,
													 image_url: src,
													 price: Haravan.formatMoney(item.price, '{{amount}}₫'),
													 title: item.title,
													 quanty: item.quantity,
													 variant_title: item.variant_title,
													 price_quanty: Haravan.formatMoney(item.price * item.quantity, "{{amount}}₫"),
													 id_item: item.variant_id
												 }];
											 }


											 $(function() {
												 var TemplateItemPopupCart = $('script[data-template="TemplateItemPopupCart"]').text().split(/\$\{(.+?)\}/g);
												 $(table).append(ItemPopupCart.map(function(item) {
													 return TemplateItemPopupCart.map(render(item)).join('');
												 }));
											 });					  

											 $('.link_product').text();
										 }); 
									 }
								 }
							 });
						 }
					 }
					 jQuery('.total-price').html(Haravan.formatMoney(cart.total_price, "{{amount}}₫"));
					 updateCartDesc(cart);
				 }
				 Haravan.updateCartPageFormMobile = function(cart, cart_summary_id, cart_count_id) {
					 if ((typeof cart_summary_id) === 'string') {
						 var cart_summary = jQuery(cart_summary_id);
						 if (cart_summary.length) {
							 // Start from scratch.
							 cart_summary.empty();
							 // Pull it all out.
							 if (cart.items && cart.items.length) {
								 var table = jQuery(cart_summary_id);           
								 jQuery('<div class="cart_page_mobile content-product-list"></div>').appendTo(table);
								 jQuery.each(cart.items, function(i, item) {
									 if ( item.image != null) {
										 var src = Haravan.resizeImage(item.image, 'compact');
									 } else {
										 var src = "//theme.hstatic.net/200000551679/1001345525/14/noimage.gif?v=1469";
									 }
									 var titlevar = item.variant_title.toLowerCase();
									 var ItemCartPageMobile = [{
										 index: i+1,
										 url: item.url,
										 image_url: src,
										 price: Haravan.formatMoney(item.price, '{{amount}}₫'),
										 title: item.title,
										 quanty: item.quantity, 
										 variant_title: titlevar !== 'default title' ? item.variant_title : '',
										 price_quanty: Haravan.formatMoney(item.price * item.quantity, "{{amount}}₫"),
										 id_item: item.variant_id,
										 line_index: i+1,
										 pd_id: item.product_id
									 }];

									 var pageCartItemMobile = $('script[data-template="ItemCartMobile"]').text().split(/\$\{(.+?)\}/g);

									 $(table.children('.content-product-list')).append(ItemCartPageMobile.map(function(item) {
										 return pageCartItemMobile.map(render(item)).join('');
									 }));
									 
								 })

								 var pageCartCheckoutMobile = $('script[data-template="pageCartCheckoutMobile"]').text().split(/\$\{(.+?)\}/g);  
								 var PriceTotalCheckoutMobile = [{
									 price_total: Haravan.formatMoney(cart.total_price, "{{amount}}₫")
								 }];
								 if(window.innerWidth < 767 ){
									 var stickyCartCheckout = $('script[data-template="templateStickyCheckout"]').text().split(/\$\{(.+?)\}/g);  
									 $('body').append(PriceTotalCheckoutMobile.map(function(item) {
										 return stickyCartCheckout.map(render(item)).join('');
									 }));
								 }										
								 $(table).append(PriceTotalCheckoutMobile.map(function(item) {
									 return pageCartCheckoutMobile.map(render(item)).join('');
								 }));


								 $('.cart_page_mobile').append(`<div class="cart-note">
<label for="note" class="note-label">Ghi chú đơn hàng</label>
<textarea id="note" name="note" rows="8"></textarea>
	</div>`)
							 }

						 }
					 }
					 updateCartDesc(cart);
				 }


				 function updateCartDesc(data){
					 var $cartPrice = Haravan.formatMoney(data.total_price, "{{amount}}₫"),
							 $cartMobile = $('#header .cart-mobile .quantity-product'),
							 $cartDesktop = $('.count_item_pr, .count_sidebar, .cart-popup-count'),
							 $cartDesktopList = $('.cart-counter-list'),
							 $cartPopup = $('.cart-popup-count');

					 switch(data.item_count){
						 case 0:
							 $cartMobile.text('0');
							 $cartDesktop.text('0');
							 $cartDesktopList.text('0');
							 $cartPopup.text('0');

							 break;
						 case 1:
							 $cartMobile.text('1');
							 $cartDesktop.text('1');
							 $cartDesktopList.text('1');
							 $cartPopup.text('1');

							 break;
						 default:
							 $cartMobile.text(data.item_count);
							 $cartDesktop.text(data.item_count);
							 $cartDesktopList.text(data.item_count);
							 $cartPopup.text(data.item_count);

							 break;
					 }
					 $('.top-cart-content .top-subtotal .price, aside.sidebar .block-cart .subtotal .price, .popup-total .total-price').html($cartPrice);
					 $('.popup-total .total-price').html($cartPrice);
					 $('.shopping-cart-table-total .totals_price, .price_sidebar .price_total_sidebar').html($cartPrice);
					 $('.totals_price_mobile').html($cartPrice);
					 $('.cartCount, .cart-popup-count, #ega-cart-count').html(data.item_count);


				 }

				 Haravan.onCartUpdate = function(cart) {
					 Haravan.updateCartFromForm(cart, '.mini-products-list');
					 Haravan.updateCartPopupForm(cart, '#popup-cart-desktop .tbody-popup');
					 
						};
						Haravan.onCartUpdateClick = function(cart, variantId) {
							jQuery.each(cart, function(key, value) {
								if (key === 'items') {    
									jQuery.each(value, function(i, item) {	
										if(item.variant_id == variantId){
											$('.productid-'+variantId).find('.cart-price span.price').html(Haravan.formatMoney(item.price * item.quantity, "{{amount}}₫"));
											$('.productid-'+variantId).find('.items-count').prop("disabled", false);
											$('.productid-'+variantId).find('.number-sidebar').prop("disabled", false);
											$('.productid-'+variantId +' .number-sidebar').val(item.quantity);
											$('.list-item-cart .item.productid-'+variantId).find( '.quanlity').text('x ' + item.quantity) 
											if(item.quantity == '1'){
												$('.productid-'+variantId).find('.items-count.btn-minus').prop("disabled", true);
											}
										}
									}); 
								}
							});
							updateCartDesc(cart);
						}
						Haravan.onCartRemoveClick = function(cart, variantId) {
							jQuery.each(cart, function(key, value) {
								if (key === 'items') {    
									jQuery.each(value, function(i, item) {	
										if(item.variant_id == variantId){
											$('.productid-'+variantId).remove();
										}
									}); 
								}
							});
							updateCartDesc(cart);
						}
						const initCart = ()=>{
							$.ajax({
								type: 'GET',
								url: '/cart.js',
								async: false,
								cache: false,
								dataType: 'json',
								success: function (cart){
									get_cart();

									Haravan.updateCartFromForm(cart, '.mini-products-list');
									Haravan.updateCartPopupForm(cart, '#popup-cart-desktop .tbody-popup'); 
									
									 }
									});

									var wDWs = $(window).width();
									if (wDWs < 1199) {
										$('.top-cart-content').remove();

									}									

								}														
								$(window).ready(function(){
								

								 $(window).one(' mousemove touchstart scroll',initCart)	
									

									});

									//Check inventory
									$(document).on('click', ".items-count", function () {
										$(this).parent().children('.items-count').prop('disabled', true);
										var variantId = $(this).parent().find('.variantID').val(),
												qty = $(this).parent().children('.number-sidebar').val(),
												url = $(this).parent().parent().parent().find('.product-name a').attr('href');
										CheckQtyCart(qty, variantId, url);
									})
																		 function CheckQtyCart(qty, variantId, url) {
										 if(!url) return																	
										 $.ajax({
											 type : 'GET',
											 dataType : 'json',
											 url: ""+url+".json",
											 success : function(data) {
												 locationData = data.product;
												 for(var i = 0; i < locationData.variants.length; i++) {
													 if(locationData.variants[i].id == variantId){
														 var maxS = locationData.variants[i].inventory_quantity,
																 allow = locationData.variants[i].inventory_management,
																 continues = locationData.variants[i].inventory_policy;
														 if (allow == 'haravan'){
															 $('.productid-'+variantId+'').find('.items-count.btn-plus').css("pointer-events","auto");
															 if (continues == "deny") {
																 $('.productid-'+variantId+'').find('.items-count.btn-plus').css("pointer-events","none");
																 if (qty >= maxS) {
																	 updateQuantity(maxS, variantId);
																	 $('.productid-'+variantId+'').find('.quanlity').text(`x ${maxS}`)
																	 $('.productid-'+variantId+'').find('.items-count.btn-plus').css("pointer-events","none");
																 }else {
																	 $('.productid-'+variantId+'').find('.items-count.btn-plus').css("pointer-events","auto");
																 }
															 } else if (continues == "continue") {
																 $('.productid-'+variantId+'').find('.items-count.btn-plus').css("pointer-events","auto");
															 } else{
																 $('.productid-'+variantId+'').find('.items-count.btn-plus').css("pointer-events","auto");
															 }
														 }
													 }
												 }
											 }
										 })
									 }
										Haravan.OptionSelectors.prototype.fireOnChangeForFirstDropdown = function (options) {
											if (this.selectors && this.selectors.length && this.selectors.length > 0) {
												this.selectors[0].element.onchange(options);
											}
										};
										function alertInvalidQty(qty){
											alert(`Bạn chỉ có thể mua tối đa ${qty} sản phẩm`)			
										}
										function validateQty(product, variantId, qty){
											let isInValidQty = false;
											/** check variant **/
											let variant = product && product.variants.find(item => item.id == variantId )
											if(variant && variant.inventory_management === "haravan" && variant.inventory_policy == "deny" ){
												isInValidQty = qty > variant.inventory_quantity 
												isInValidQty && alertInvalidQty(variant.inventory_quantity)
												return isInValidQty ? variant.inventory_quantity: false
											}
											return 	isInValidQty

										}

										function cart_min() {
											var sts = true;
											$.ajax({
												type: 'GET',
												url: '/cart.js',
												async: false,
												success:function(data) {
													var cart = parseInt(data.total_price);
													var cart_compare = parseInt(0);
																																																																	 if(cart < cart_compare) {
																																																																		 $('.btn-proceed-checkout-mobile').addClass('disabled');
																																																																		 $('.cart-limit-alert').css('display', 'block');
																																																																		 $('#template-cart').removeClass('cart-available')
																																																																		 sts = false;
																																																																	 } else {
																																																																		 $('.btn-proceed-checkout-mobile').removeClass('disabled');
																																																																		 $('.cart-limit-alert').css('display', 'none');
																																																																		 $('#template-cart').addClass('cart-available')
																																																																	 }
																																																																	}
									 })
									 return sts;
									}

									
											Haravan.OptionSelectors.prototype.fireOnChangeForFirstDropdown = function (options) {
												if (this.selectors && this.selectors.length && this.selectors.length > 0) {
													this.selectors[0].element.onchange(options);
												}
											};

</script>
		
		<script>
			var vendors ="//theme.hstatic.net/200000551679/1001345525/14/vendors.js?v=1469 "
		</script>
		<link rel="preload" as="script" href="//theme.hstatic.net/200000551679/1001345525/14/main.js?v=1469" />
		<script src='//theme.hstatic.net/200000551679/1001345525/14/main.js?v=1469' type='text/javascript'></script>
		
		

		<script src='//theme.hstatic.net/200000551679/1001345525/14/ega-gateway-min.js?v=1469' type='text/javascript'></script>
				<script>
	var cro_show = true,
		cro_addcart_show = false,
		cro_cart_show =false,
		cro_addcart_title = "Thêm vào giỏ",
		cro_addcart_bg_1 = "#d82e4d",
		cro_addcart_bg_2 = "#d82e4d",
		cro_addcart_color = "#fff",
		cro_price_color = "#f3283d",
		cro_variant_color = "#d82e4d",
		cro_cta_bg = "#d82e4d",
		cro_cta_color = "",
		cro_addcart_modal_mess = "Tiến hành thanh toán",
		cro_addcart_modal_redirect = "",
		cro_modal_btn_text = "",
		cro_modal_btn_bg = "",
		cro_modal_btn_color = "",
		cro_hotline_show =  true,
		cro_hotline_number = "19002631",
		cro_mess_show = true,
		cro_mess_url = "https://m.me/Sammishop.com86",
		cro_home_show = 3,
		cro_home_title = "Ưu đãi",
		cro_home_url = "/collections/hot-sale-thang-moi/",
		cro_coll_title = "Sản phẩm",
		cro_coll_url = "/collections/all",
		cro_blog_title = "Cửa hàng",
		cro_blog_url = "/pages/he-thong-cua-hang-1",
		cro_general_color = "#d82e4d",
		cro_product_color = "#d82e4d",
		cro_background_color = "#fff"
		
	window.EGACRAddonSettings = {
		general: {
			enabled: cro_show,
			iconWidth: 20,
			background: cro_background_color,
			color: cro_general_color,
			activeColor: cro_general_color,
			activeBackground: cro_background_color,
			screenSize: [{ name: "mobile" }],
			styleAddon: "shopee",
			productBackground: "#ffffff",
			productColor: cro_product_color,
			ignorePages: [],
			bodyOffset: 54,
			conflictEl: "#ega-hotline,.fb_dialog.fb_dialog_advanced",
			skipEl: ".button-popup-loyalty",
			desktop: { x: "right", y: 50 }
		},
		products: {
			enabled: cro_cart_show || cro_addcart_show ,
			cart: {
				enabled: cro_cart_show,
				icon: "//theme.hstatic.net/200000551679/1001345525/14/cro_cart-icon.png?v=1469",
				title: "Giỏ hàng",
				url: "/cart"
			},
			buyNowBtn: {
				enabled: false,
				title: "Mua ngay",
				color: "#ffffff",
				background: "#ffd001",
				backgroundEnd: "#ff9b30"
			},
			addToCartBtn: {
				enabled: cro_addcart_show,
				title: cro_addcart_title,
				color: "#ffffff",
				background: cro_addcart_bg_1,
				loadingColor: "",
				icon: "",
				backgroundEnd: cro_addcart_bg_2,
				cartQuery: ".count_item_pr,.count-holder .count"
			},
			modal: {
				enabled: false,
				headerText: "Sản phẩm vừa được thêm vào giỏ hàng",
				ctaLink: "checkout",
				ctaText: cro_addcart_modal_mess,
				ctaBg: "#ff5722",
				ctaColor: "#fff"
			},
			qvProduct: {
				priceColor: cro_price_color,
				variantColor: cro_variant_color,
				ctaBg: cro_addcart_bg_1,
				ctaColor: "#fff",
				useQty: true
			}
		},
		pages: {
			enabled: true,
			links: [
				
				{
					url: cro_coll_url,
					title: cro_coll_title,
					icon:"//theme.hstatic.net/200000551679/1001345525/14/icon_cro_coll.png?v=1469",
					order: "4"
				},
												{
					url: cro_blog_url,
					title: cro_blog_title,
					icon:"//theme.hstatic.net/200000551679/1001345525/14/icon_cro_blog.png?v=1469",
					order: "5"

				},
								
				{
					url: cro_home_url,
					title: cro_home_title,
					icon:"//theme.hstatic.net/200000551679/1001345525/14/cro_home-icon.png?v=1469",
					order: "3"

				}
							]
		},
		messenger: {
			enabled: cro_mess_show,
			icon:"//theme.hstatic.net/200000551679/1001345525/14/cro_mess-icon.png?v=1469",
			title: "Nhắn tin",
			url: cro_mess_url,
			
			order: "2"
			

		},
		phone: {
			enabled: cro_hotline_show,
			icon: "//theme.hstatic.net/200000551679/1001345525/14/cro_phone-icon.png?v=1469",
			title: "Gọi điện",
			number: cro_hotline_number,
			
			order: "1"
						

		},
		form: {
	enabled: false,
		}
	};
	let crAddonScript= "//theme.hstatic.net/200000551679/1001345525/14/ega.addon-cr-button.min.js?v=1469"
		EGACRAddonSettings.general.currentTemplate = '404';
	EGACRAddonSettings.general.platform  = Haravan;
	window.EGACRAddonSettings.general.moneyFormat = '{{amount}}₫'
	const platform = window.EGACRAddonSettings.general.platform
	platform.addItem = function(variantId, quantity,callback,errHandle){
		var quantity = quantity || 1;
		
	
		var boolCombo = false;
	  var boolBuyXgetY = false;
		 if($("#add-to-cart-form").length > 0){
			 if($("#add-to-cart-form").find(".add_to_cart").hasClass("product-combo")){
				 boolCombo = true;
			 }
			 if($("#add-to-cart-form").find(".add_to_cart").hasClass("product-buyxgety")){
				 boolBuyXgetY = true;
			 }
		 }

		 if(boolCombo){
			 $('#popupComboModal').modal();
		 } else if(boolBuyXgetY){
			 buyXgetY.addCartBuyXGetY_detail(true,variantId,quantity,(jqXHR, textStatus, errorThrown) => {
				 $('#crQVModal').trigger('click')
					$('#cr-addon-addtocart').removeClass('loading').removeAttr("disabled")
				 addToCartSuccess(jqXHR, textStatus, errorThrown)
			 })
		 }else {
			n = {
				type: "POST",
				url: "/cart/add.js",
				data: "quantity=" + quantity + "&id=" + variantId,
				dataType: "json",
				success: function(jqXHR, textStatus, errorThrown) {
					$('#crQVModal').trigger('click')
					$('#cr-addon-addtocart').removeClass('loading').removeAttr("disabled")
					addToCartSuccess(jqXHR, textStatus, errorThrown)
				},
				error: function(a, r) {
					errHandle(a, r)
				}
			};
			jQuery.ajax(n)
		}
	}
	if(typeof EGA === 'undefined'){
		EGA = {}
	}
	window.egaCRAddonValid = window.EGACRAddonSettings.general.enabled;
	
	$(document).ready(function ($) {
		if(window.innerWidth <= 600){
		var isInit = false
		$(window).on('scroll click mousemove touchstart',()=>{
			if(!isInit){
				isInit = true
				$("body").append(`<script src="${crAddonScript}" defer ><\/script>`);
			}
		})
		}
	});
	
</script>

				<!-- Add to cart -->
		<div id="popupCartModal" class="modal fade" role="dialog">
		</div>
		
		<link rel="stylesheet" href="//theme.hstatic.net/200000551679/1001345525/14/addthis-sharing.css?v=1469" media="print" onload="this.media='all'">

<noscript><link href='//theme.hstatic.net/200000551679/1001345525/14/addthis-sharing.css?v=1469' rel='stylesheet' type='text/css'  media='all'  /></noscript>	
<div class="addThis_listSharing ">
	
	<a href="#" id="back-to-top" class="backtop back-to-top d-flex align-items-center justify-content-center"  title="Lên đầu trang">
		

<svg class="icon" style="transform: rotate(-90deg)"
>
	<use xlink:href="#icon-arrow" />
</svg>
	</a>
	

	<ul class="addThis_listing list-unstyled  d-none d-sm-block">

		<li class="addThis_item">
			<a class="addThis_item--icon" href="tel:19002631" rel="nofollow" >
				<svg viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg"> 
					<circle cx="22" cy="22" r="22" fill="url(#paint2_linear)" /> <path fill-rule="evenodd" clip-rule="evenodd" d="M14.0087 9.35552C14.1581 9.40663 14.3885 9.52591 14.5208 9.61114C15.3315 10.148 17.5888 13.0324 18.3271 14.4726C18.7495 15.2949 18.8903 15.9041 18.758 16.3558C18.6214 16.8415 18.3953 17.0971 17.384 17.9109C16.9786 18.239 16.5988 18.5756 16.5391 18.6651C16.3855 18.8866 16.2617 19.3212 16.2617 19.628C16.266 20.3395 16.7269 21.6305 17.3328 22.6232C17.8021 23.3944 18.6428 24.3828 19.4749 25.1413C20.452 26.0361 21.314 26.6453 22.2869 27.1268C23.5372 27.7488 24.301 27.9064 24.86 27.6466C25.0008 27.5826 25.1501 27.4974 25.1971 27.4591C25.2397 27.4208 25.5683 27.0202 25.9268 26.5772C26.618 25.7079 26.7759 25.5674 27.2496 25.4055C27.8513 25.201 28.4657 25.2563 29.0844 25.5716C29.5538 25.8145 30.5779 26.4493 31.2393 26.9095C32.1098 27.5187 33.9703 29.0355 34.2221 29.3381C34.6658 29.8834 34.7427 30.5821 34.4439 31.3534C34.1281 32.1671 32.8992 33.6925 32.0415 34.3444C31.2649 34.9323 30.7145 35.1581 29.9891 35.1922C29.3917 35.222 29.1442 35.1709 28.3804 34.8556C22.3893 32.3887 17.6059 28.7075 13.8081 23.65C11.8239 21.0084 10.3134 18.2688 9.28067 15.427C8.67905 13.7696 8.64921 13.0495 9.14413 12.2017C9.35753 11.8438 10.2664 10.9575 10.9278 10.4633C12.0288 9.64524 12.5365 9.34273 12.9419 9.25754C13.2193 9.19787 13.7014 9.24473 14.0087 9.35552Z" fill="white" /> <defs> <linearGradient id="paint2_linear" x1="22" y1="-7.26346e-09" x2="22.1219" y2="40.5458" gradientUnits="userSpaceOnUse"> <stop stop-color="#e8434c" offset="0"/> <stop offset="1" stop-color="#d61114" /> </linearGradient> </defs> </svg>
				<span class="tooltip-text">Gọi ngay cho chúng tôi</span>
			</a>
		</li>
		<li class="addThis_item">
			<a class="addThis_item--icon" href="https://zalo.me/4034357249438657314" target="_blank"  rel="nofollow">
				<img class="img-fluid" src="//theme.hstatic.net/200000551679/1001345525/14/addthis-zalo.svg?v=1469" alt="Chat với chúng tôi qua Zalo" loading="lazy" width="44" height="44" />
				<span class="tooltip-text">Chat với chúng tôi qua Zalo</span>
			</a>
		</li>

	</ul>
</div>
<!-- Messenger Plugin chat Code -->
<div id="fb-root"></div>

<!-- Your Plugin chat code -->
<div id="fb-customer-chat" class="fb-customerchat">
</div>

<script>

	$(document).ready(() => {
		const page_id = "168389884826236"
		if(page_id && window.innerWidth  > 600){
			$(window).one(' mousemove touchstart scroll', () => {
				var chatbox = document.getElementById('fb-customer-chat');
				chatbox.setAttribute("page_id", page_id);
				chatbox.setAttribute("attribution", "biz_inbox");

				window.fbAsyncInit = function() {
					FB.init({
						xfbml            : true,
						version          : 'v12.0'
					});
				};

				(function(d, s, id) {
					var js, fjs = d.getElementsByTagName(s)[0];
					if (d.getElementById(id)) return;
					js = d.createElement(s); js.id = id;
					js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
					fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));
			})
		}
	})

</script>


		
		<link rel="preload" as="script" href="//theme.hstatic.net/200000551679/1001345525/14/ega-builtin-smartsearch-configs.js?v=1469">
		<script src='//theme.hstatic.net/200000551679/1001345525/14/ega-builtin-smartsearch-configs.js?v=1469' type='text/javascript'></script>	
		
		


		
		

		
<div class="hidden hiden hide d-none">
	<div class="thecartcheck">

	</div>
</div>

<script>

	function checkcartonly(){
		var giatiensetings = parseFloat("299000");
		if($(".icart").attr("datakm") != ''){
			giatiensetings = parseFloat($(".icart").attr("datakm"));
		}
		var tienphaico = Haravan.formatMoney(giatiensetings + '00', "{{amount}}₫");

		var htmlc = "<div></div>";
		htmlc += "<div class='toithieu'>Sản phẩm khuyến mãi đang có trong giỏ hàng là: <span class='ztitlemy'>"+$(".icart").attr("datatitle")+"</span></div>";
		htmlc += "<div class=''>Số tiền tối thiểu của đơn hàng để được thanh toán là trên:<span class='ztitlemy'> "+tienphaico+"</span></div>";
		
		$(".contentthongbao").html(htmlc);
		$('#insPopupNewletter').addClass('active');
		
		
	}
</script>








		
		<script>
			if (!f1genzPS) {
				(jQuery.event.special.touchstart = {
					setup: function (e, t, n) {
						this.addEventListener("touchstart", n, {
							passive: !t.includes("noPreventDefault"),
						});
					},
				}),
					(jQuery.event.special.touchmove = {
					setup: function (e, t, n) {
						this.addEventListener("touchmove", n, {
							passive: !t.includes("noPreventDefault"),
						});
					},
				});
			}
			/*$(function(){
				$('.quatang').each(function(){
					var a = $(this).data('id');
					$.getJSON("https://buyxgety-omni.haravan.com/js/recommendeds?product_id=" + $(this).data('id'), function(result){
						$.each(result, function(i, field){
							if(result.recommendeds[0] != undefined){
								$('.quatang[data-id="'+ a +'"]').html('<span>Tặng ' + result.recommendeds[0].product_name.replace('[HÀNG TẶNG KHÔNG BÁN] ', '') + '</span')						
							}else{
								$('.quatang[data-id="'+ a +'"]').remove()
							}					
						});
					});
				})
			})*/
			/*$(document).ajaxStop(function() {
				$('.quatang').each(function(){
					var a = $(this).data('id');
					$.getJSON("https://buyxgety-omni.haravan.com/js/recommendeds?product_id=" + $(this).data('id'), function(result){
						$.each(result, function(i, field){
							if(result.recommendeds[0] != undefined){
								$('.quatang[data-id="'+ a +'"]').html('<span>Tặng ' + result.recommendeds[0].product_name.replace('[HÀNG TẶNG KHÔNG BÁN] ', '') + '</span')						
							}else{
								$('.quatang[data-id="'+ a +'"]').remove()
							}					
						});
					});
				})
			});*/
		</script>

		



	</body>
</html>
